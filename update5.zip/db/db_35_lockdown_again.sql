-- =====================================================================
--  db_35_lockdown_again.sql  (نفس قفل الأمان تاني بعد التحديثات 26-32) — شغّله آخر حاجة
-- =====================================================================

-- 1) قفل كل الدوال عن الكل، وبعدين نفتح بالاسم
do $$
declare r record;
begin
  for r in select p.oid::regprocedure as sig from pg_proc p join pg_namespace n on n.oid = p.pronamespace
            where n.nspname = 'public' and p.prokind in ('f', 'p') loop
    execute 'revoke all on function ' || r.sig || ' from public, anon, authenticated';
  end loop;
end $$;

-- 2) دوال المتصفح للمسجّل دخوله (كل دالة بتتأكد من الصلاحية جواها)
do $$
declare r record;
begin
  for r in select p.oid::regprocedure as sig from pg_proc p join pg_namespace n on n.oid = p.pronamespace
            where n.nspname = 'public' and p.prokind = 'f'
              and p.proname not in ('_audit', '_audit_trg', '_bn_touch', '_claim_session', '_purge_codes', '_report_quiz', '_video_url',
                                    '_link_owner', '_owner_email', 'link_owner_now', 'grade_attempt', 'quiz_recompute', 'quiz_apply_multi', '_essay_parts', '_blank_to_null',
                                    '_regrade_question', '_trg_regrade_answer', '_trg_regrade_question', '_exam_matrix', '_lb', '_eff_close', '_pname',
                                    '_obj_size', '_support_path', '_frame_defaults', '_frame_clean', '_qp_check', '_sigv4_get',
                                    '_is_banned', '_ban_guard', '_ban_guard_profile', '_expire_suspension', '_on_signin_expire', '_video_pct', '_merge_ranges', '_ranges_sum', '_r2_get') loop
    execute 'grant execute on function ' || r.sig || ' to authenticated';
  end loop;
end $$;

-- 3) دوال تشتغل من غير تسجيل دخول (التسجيل الجديد + الدعم الفني برقم مسجّل)
grant execute on function public.student_exists(text, text) to anon;
do $$
declare r record;
begin
  for r in select p.oid::regprocedure as sig from pg_proc p join pg_namespace n on n.oid = p.pronamespace
            where n.nspname = 'public' and p.proname in ('support_start', 'support_send', 'support_fetch', 'support_begin') loop
    execute 'grant execute on function ' || r.sig || ' to anon';
  end loop;
end $$;

-- 4) الجداول: غير المسجّل ما يلمسش أي جدول، والمسجّل ما يكتبش في الجداول الحساسة مباشرة
revoke all on all tables in schema public from anon;
revoke all on all sequences in schema public from anon;
revoke all on public.admins, public.staff, public.access_locks, public.quiz_starts, public.quiz_live_drafts, public.code_attempts,
  public.active_sessions, public.item_views, public.notif_reads, public.support_threads, public.support_messages,
  public.banner_dismissals, public.site_settings, public.quiz_extensions, public.banned_identities from authenticated;
revoke insert, update, delete on public.quiz_attempts, public.quiz_attempt_answers, public.quiz_attempt_archive,
  public.login_events, public.admin_audit, public.item_progress from authenticated;
revoke insert, update on public.activation_codes from authenticated;
revoke update, delete on public.profiles, public.lesson_progress from authenticated;
revoke update on public.enrollments from authenticated;

notify pgrst, 'reload schema';

-- 5) فحص نهائي (كله لازم يطلع ✅)
select * from (
  select 'عدد الجداول (المفروض 39)' as الفحص, count(*)::text as النتيجة, (count(*) = 39) as سليم
    from pg_tables where schemaname = 'public'
  union all
  select 'كل الجداول عليها RLS', count(*)::text || ' بدون RLS', (count(*) = 0)
    from pg_tables where schemaname = 'public' and not rowsecurity
  union all
  select 'دوال مفتوحة لغير المسجّل (المفروض 4: student_exists + 4 دعم فني)', string_agg(distinct p.proname, ', '), true
    from pg_proc p join pg_namespace n on n.oid = p.pronamespace
   where n.nspname = 'public' and p.prokind = 'f' and has_function_privilege('anon', p.oid, 'execute')
  union all
  select 'دوال start_quiz/submit_quiz/quiz_submit_full موجودة',
         (to_regprocedure('public.start_quiz(uuid)') is not null and to_regprocedure('public.submit_quiz(uuid, jsonb, integer)') is not null
          and to_regprocedure('public.quiz_submit_full(uuid, jsonb, integer)') is not null)::text,
         (to_regprocedure('public.start_quiz(uuid)') is not null and to_regprocedure('public.submit_quiz(uuid, jsonb, integer)') is not null
          and to_regprocedure('public.quiz_submit_full(uuid, jsonb, integer)') is not null)
  union all
  select 'تريجر المالك شغّال', (count(*))::text, (count(*) = 1) from pg_trigger where tgname = 'on_auth_user_owner' and not tgisinternal
  union all
  select 'إيميل المالك', public._owner_email(), true
  union all
  select 'عدد المسؤولين الحاليين (0 = لسه محدش عمل حساب بإيميل المالك)', count(*)::text, true from public.admins
) f;
