-- =====================================================================
--  db_32_accounts_video_classes.sql
--  1) حالات الحساب: إيقاف مؤقت / إيقاف نهائي / حظر / حذف (ويقدر الطالب يسجّل من جديد إلا لو محظور)
--  2) تتبّع تغطية الفيديو الفعلية (وقت الفيديو نفسه — مهما كانت السرعة)
--  3) تقرير الصفوف (صف ← طلاب ← كورسات ← دروس ← سمع كام من كام)
--  4) أكثر من حساب Bunny (مفتاح لكل مكتبة) وأكثر من حساب R2
--  شغّله في New query لوحده بعد db_31.
-- =====================================================================

-- ---------------------------------------------------------------- 1) حالات الحساب
alter table public.profiles add column if not exists account_status text not null default 'active';
alter table public.profiles add column if not exists suspended_until timestamptz;
alter table public.profiles add column if not exists status_reason text;
alter table public.profiles add column if not exists status_at timestamptz;
alter table public.profiles drop constraint if exists profiles_status_ok;
alter table public.profiles add constraint profiles_status_ok check (account_status in ('active', 'suspended', 'stopped', 'banned'));
update public.profiles set account_status = 'stopped', status_at = coalesce(status_at, now()) where is_blocked and account_status = 'active';

create table if not exists public.banned_identities (
  id uuid primary key default gen_random_uuid(),
  email text,
  phone text,
  name text,
  reason text,
  created_at timestamptz not null default now(),
  created_by uuid
);
create index if not exists banned_identities_email_idx on public.banned_identities (lower(email));
create index if not exists banned_identities_phone_idx on public.banned_identities (phone);
alter table public.banned_identities enable row level security;
revoke all on public.banned_identities from anon, authenticated;

create or replace function public._is_banned(p_email text, p_phone text)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select exists (select 1 from banned_identities b
                  where (nullif(btrim(coalesce(p_email, '')), '') is not null and lower(b.email) = lower(btrim(p_email)))
                     or (nullif(btrim(coalesce(p_phone, '')), '') is not null and b.phone = btrim(p_phone)));
$function$;

-- منع التسجيل بإيميل/رقم محظور (قبل ما الحساب يتعمل أصلاً)
create or replace function public._ban_guard()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v text; hit boolean := false;
begin
  if public._is_banned(new.email, null) then raise exception 'banned_identity'; end if;
  begin
    for v in select value from jsonb_each_text(coalesce(new.raw_user_meta_data, '{}'::jsonb)) loop
      if v ~ '^01[0-9]{9}$' and public._is_banned(null, v) then hit := true; end if;
    end loop;
  exception when others then hit := false; end;
  if hit then raise exception 'banned_identity'; end if;
  return new;
end $function$;

create or replace function public._ban_guard_profile()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if public._is_banned(new.email, new.phone_number) then raise exception 'banned_identity'; end if;
  return new;
end $function$;

do $$ begin
  begin
    drop trigger if exists ban_guard_auth on auth.users;
    create trigger ban_guard_auth before insert on auth.users for each row execute function public._ban_guard();
  exception when others then raise notice 'ban_guard_auth skipped: %', sqlerrm; end;
end $$;
drop trigger if exists ban_guard_profile on public.profiles;
create trigger ban_guard_profile before insert on public.profiles for each row execute function public._ban_guard_profile();

-- انتهاء الإيقاف المؤقت تلقائياً
create or replace function public._expire_suspension(p_uid uuid DEFAULT NULL)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  update profiles set account_status = 'active', is_blocked = false, suspended_until = null, status_reason = null, status_at = now()
   where account_status = 'suspended' and suspended_until is not null and suspended_until <= now() and (p_uid is null or id = p_uid);
end $function$;

create or replace function public._on_signin_expire()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  begin perform public._expire_suspension(new.id); exception when others then null; end;
  return new;
end $function$;

do $$ begin
  begin
    drop trigger if exists signin_expire_suspension on auth.users;
    create trigger signin_expire_suspension after update of last_sign_in_at on auth.users for each row execute function public._on_signin_expire();
  exception when others then raise notice 'signin_expire skipped: %', sqlerrm; end;
end $$;

-- الطالب نفسه: لو إيقافه المؤقت خلص يتفتح الحساب، ويرجعله حالته. (p_all = للإدارة: تنضيف الكل)
create or replace function public.account_gate(p_all boolean DEFAULT false)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare r record;
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  if coalesce(p_all, false) and public.has_perm('students.view') then perform public._expire_suspension(null);
  else perform public._expire_suspension(auth.uid()); end if;
  select account_status, suspended_until, status_reason, is_blocked into r from profiles where id = auth.uid();
  return jsonb_build_object('status', r.account_status, 'until', r.suspended_until, 'reason', r.status_reason, 'blocked', coalesce(r.is_blocked, false));
end $function$;

create or replace function public.set_account_status(p_student uuid, p_status text, p_until timestamptz DEFAULT NULL, p_reason text DEFAULT NULL)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare pr profiles%rowtype;
begin
  if not public.has_perm('students.block') then raise exception 'forbidden'; end if;
  if p_status not in ('active', 'suspended', 'stopped', 'banned') then raise exception 'bad_status'; end if;
  if p_student = auth.uid() then raise exception 'cannot_self'; end if;
  if exists (select 1 from admins where user_id = p_student) or exists (select 1 from staff where user_id = p_student) then raise exception 'cannot_staff'; end if;
  select * into pr from profiles where id = p_student; if not found then raise exception 'not_found'; end if;
  if p_status = 'suspended' and (p_until is null or p_until <= now()) then raise exception 'bad_until'; end if;
  p_reason := nullif(left(btrim(coalesce(p_reason, '')), 300), '');
  update profiles set account_status = p_status, is_blocked = (p_status <> 'active'),
         suspended_until = case when p_status = 'suspended' then p_until end,
         status_reason = case when p_status = 'active' then null else p_reason end, status_at = now()
   where id = p_student;
  if p_status = 'banned' then
    if not exists (select 1 from banned_identities where lower(email) = lower(pr.email) or phone = pr.phone_number) then
      insert into banned_identities (email, phone, name, reason, created_by) values (lower(pr.email), pr.phone_number, public._pname(pr), p_reason, auth.uid());
    end if;
  else
    delete from banned_identities where lower(email) = lower(pr.email) or phone = pr.phone_number;
  end if;
  if p_status <> 'active' then
    delete from active_sessions where user_id = p_student;
    insert into active_sessions (user_id, session_id, session_created) values (p_student, 'kicked-' || gen_random_uuid()::text, now());
    begin delete from auth.sessions where user_id = p_student; exception when others then null; end;
  end if;
  perform public._audit('student.status', public._pname(pr), jsonb_build_object('status', p_status, 'until', p_until, 'reason', p_reason));
end $function$;

-- الدالة القديمة (إيقاف/إلغاء إيقاف) بتفضل شغالة وبتستخدم الحالات الجديدة
create or replace function public.set_blocked(p_student uuid, p_blocked boolean)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  perform public.set_account_status(p_student, case when coalesce(p_blocked, false) then 'stopped' else 'active' end, null, null);
end $function$;

-- حذف الحساب نهائياً (كل بياناته) — ويقدر يسجّل حساب جديد عادي، إلا لو اخترت «احظره بعد الحذف»
create or replace function public.admin_delete_student(p_student uuid, p_ban boolean DEFAULT false, p_reason text DEFAULT NULL)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare pr profiles%rowtype; nm text;
begin
  if not public.has_perm('students.delete') then raise exception 'forbidden'; end if;
  if p_student = auth.uid() then raise exception 'cannot_self'; end if;
  if exists (select 1 from admins where user_id = p_student) or exists (select 1 from staff where user_id = p_student) then raise exception 'cannot_staff'; end if;
  select * into pr from profiles where id = p_student; if not found then raise exception 'not_found'; end if;
  nm := public._pname(pr);
  p_reason := nullif(left(btrim(coalesce(p_reason, '')), 300), '');
  if coalesce(p_ban, false) then
    insert into banned_identities (email, phone, name, reason, created_by) values (lower(pr.email), pr.phone_number, nm, p_reason, auth.uid());
  end if;
  perform public._audit('student.delete', nm, jsonb_build_object('email', pr.email, 'phone', pr.phone_number, 'year', pr.academic_year, 'ban', coalesce(p_ban, false)));
  delete from auth.users where id = p_student;
  delete from profiles where id = p_student;            -- لو مفيش cascade
end $function$;

create or replace function public.banned_list()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if not public.has_perm('students.block') then raise exception 'forbidden'; end if;
  return coalesce((select jsonb_agg(jsonb_build_object('id', id, 'email', email, 'phone', phone, 'name', name, 'reason', reason, 'created_at', created_at) order by created_at desc) from banned_identities), '[]'::jsonb);
end $function$;

create or replace function public.banned_remove(p_id uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if not public.has_perm('students.block') then raise exception 'forbidden'; end if;
  delete from banned_identities where id = p_id;
  perform public._audit('student.unban_identity', p_id::text, null);
end $function$;

-- ---------------------------------------------------------------- 2) تغطية الفيديو الفعلية
alter table public.video_progress add column if not exists ranges jsonb not null default '[]'::jsonb;
alter table public.video_progress add column if not exists covered integer not null default 0;
alter table public.video_progress add column if not exists cover_at timestamptz;

create or replace function public._video_pct()
 RETURNS integer
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select least(greatest(coalesce((select nullif(value, '')::int from site_settings where key = 'video_done_pct' and value ~ '^[0-9]{1,3}$'), 90), 50), 100);
$function$;

-- دمج مدد الفيديو المسموعة [[من,إلى],...] (بالثواني) في مدد منفصلة مرتبة
create or replace function public._merge_ranges(p jsonb, p_max integer, p_gap integer DEFAULT 1)
 RETURNS jsonb
 LANGUAGE sql
 IMMUTABLE
AS $function$
  with r as (
    select least(greatest((x ->> 0)::int, 0), p_max) as s, least(greatest((x ->> 1)::int, 0), p_max) as e
      from jsonb_array_elements(case when jsonb_typeof(p) = 'array' then p else '[]'::jsonb end) x
     where jsonb_typeof(x) = 'array' and jsonb_array_length(x) = 2 and (x ->> 0) ~ '^[0-9]{1,6}$' and (x ->> 1) ~ '^[0-9]{1,6}$'),
  r2 as (select s, e from r where e > s),
  o as (select s, e, max(e) over (order by s, e rows between unbounded preceding and 1 preceding) as pe from r2),
  g as (select s, e, sum(case when pe is null or s > pe + p_gap then 1 else 0 end) over (order by s, e) as grp from o)
  select coalesce(jsonb_agg(jsonb_build_array(a, b) order by a), '[]'::jsonb) from (select min(s) as a, max(e) as b from g group by grp) z;
$function$;

create or replace function public._ranges_sum(p jsonb)
 RETURNS integer
 LANGUAGE sql
 IMMUTABLE
AS $function$
  select coalesce(sum(((x ->> 1)::int - (x ->> 0)::int)), 0)::int from jsonb_array_elements(p) x;
$function$;

-- الطالب بيبعت المدد الجديدة اللي سمعها فعلاً (مش اللي قفز فوقها). السيرفر بيدمجها ويحسب نسبة التغطية.
create or replace function public.video_cover_save(p_item uuid, p_ranges jsonb, p_dur integer DEFAULT NULL)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare lid uuid; vp video_progress%rowtype; dur int; x jsonb; s int; e int; budget numeric; kept jsonb := '[]'::jsonb; merged jsonb; cov int; pct int := public._video_pct(); done boolean := false; had boolean;
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  select lesson_id into lid from lesson_items where id = p_item and kind = 'video';
  if lid is null then return null; end if;
  if not public.lesson_access(lid) then raise exception 'forbidden'; end if;
  if public.has_group('content') or public.has_group('students') then return null; end if;        -- معاينة الفريق ما تتحسبش
  select * into vp from video_progress where student_id = auth.uid() and item_id = p_item;
  had := found;
  dur := case when p_dur between 1 and 86400 then p_dur else vp.duration end;
  if dur is null or dur < 1 then return null; end if;
  -- ميزانية منطقية: مفيش حد يسمع أكتر من ~3 أضعاف الوقت اللي عدّى فعلاً (+هامش)
  budget := least(extract(epoch from now() - coalesce(vp.cover_at, now() - interval '60 seconds')) * 3 + 20, 1200);
  if jsonb_typeof(p_ranges) = 'array' then
    for x in select * from jsonb_array_elements(p_ranges) limit 60 loop
      continue when jsonb_typeof(x) <> 'array' or jsonb_array_length(x) <> 2 or (x ->> 0) !~ '^[0-9]{1,6}$' or (x ->> 1) !~ '^[0-9]{1,6}$';
      s := least((x ->> 0)::int, dur); e := least((x ->> 1)::int, dur);
      continue when e <= s or budget <= 0;
      if e - s > budget then e := s + budget::int; end if;
      budget := budget - (e - s);
      kept := kept || jsonb_build_array(jsonb_build_array(s, e));
    end loop;
  end if;
  merged := public._merge_ranges(coalesce(vp.ranges, '[]'::jsonb) || kept, dur, 1);
  if jsonb_array_length(merged) > 400 then merged := public._merge_ranges(merged, dur, 10); end if;
  cov := least(public._ranges_sum(merged), dur);
  insert into video_progress (student_id, item_id, seconds, duration, ranges, covered, cover_at, updated_at)
    values (auth.uid(), p_item, 0, dur, merged, cov, now(), now())
  on conflict (student_id, item_id) do update
    set ranges = excluded.ranges, covered = excluded.covered, duration = excluded.duration, cover_at = now();
  if cov * 100 >= dur * pct then
    done := true;
    if not exists (select 1 from item_progress where student_id = auth.uid() and item_id = p_item) then insert into item_progress (student_id, item_id) values (auth.uid(), p_item); end if;
  else
    done := exists (select 1 from item_progress where student_id = auth.uid() and item_id = p_item);
  end if;
  return jsonb_build_object('covered', cov, 'duration', dur, 'pct', round(cov * 100.0 / dur), 'need_pct', pct, 'done', done, 'ranges', merged);
end $function$;

create or replace function public.video_pos_get(p_item uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare r video_progress%rowtype;
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  select * into r from video_progress where student_id = auth.uid() and item_id = p_item;
  if not found then return jsonb_build_object('need_pct', public._video_pct()); end if;
  return jsonb_build_object('seconds', r.seconds, 'duration', r.duration, 'updated_at', r.updated_at, 'ranges', r.ranges, 'covered', r.covered,
                            'pct', case when coalesce(r.duration, 0) > 0 then round(r.covered * 100.0 / r.duration) end, 'need_pct', public._video_pct());
end $function$;

-- ---------------------------------------------------------------- 3) تقارير الصفوف + تقرير الطالب بالتغطية
create or replace function public.grade_overview(p_year text)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare pct int := public._video_pct();
begin
  if not public.has_perm('students.view') then raise exception 'forbidden'; end if;
  return coalesce((select jsonb_agg(jsonb_build_object(
      'id', p.id, 'name', public._pname(p), 'phone', p.phone_number, 'parent_phone', p.parent_phone, 'email', p.email, 'status', p.account_status, 'until', p.suspended_until, 'created_at', p.created_at,
      'courses', coalesce((select jsonb_agg(jsonb_build_object(
            'id', c.id, 'title', c.title,
            'lessons', (select count(*) from lessons l where l.course_id = c.id),
            'lessons_done', (select count(*) from lesson_progress lp join lessons l on l.id = lp.lesson_id where lp.student_id = p.id and l.course_id = c.id),
            'videos', (select count(*) from lesson_items i join lessons l on l.id = i.lesson_id where l.course_id = c.id and i.kind = 'video'),
            'heard', (select count(*) from lesson_items i join lessons l on l.id = i.lesson_id
                        left join video_progress vp on vp.item_id = i.id and vp.student_id = p.id
                        left join item_progress ip on ip.item_id = i.id and ip.student_id = p.id
                       where l.course_id = c.id and i.kind = 'video'
                         and ((vp.duration > 0 and vp.covered * 100 >= vp.duration * pct) or (vp.item_id is null and ip.item_id is not null))),
            'cov_sec', (select coalesce(sum(vp.covered), 0) from video_progress vp join lesson_items i on i.id = vp.item_id join lessons l on l.id = i.lesson_id where vp.student_id = p.id and l.course_id = c.id),
            'dur_sec', (select coalesce(sum(vp.duration), 0) from video_progress vp join lesson_items i on i.id = vp.item_id join lessons l on l.id = i.lesson_id where vp.student_id = p.id and l.course_id = c.id),
            'last_at', (select max(iv.last_at) from item_views iv join lesson_items i on i.id = iv.item_id join lessons l on l.id = i.lesson_id where iv.student_id = p.id and l.course_id = c.id)
          ) order by c.sort_order, c.title) from enrollments e join courses c on c.id = e.course_id where e.student_id = p.id), '[]'::jsonb)
    ) order by p.first_name, p.last_name)
    from profiles p where p.academic_year = p_year), '[]'::jsonb);
end $function$;

create or replace function public.grade_student_detail(p_student uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare pct int := public._video_pct();
begin
  if not public.has_perm('students.view') then raise exception 'forbidden'; end if;
  return jsonb_build_object('need_pct', pct, 'courses', coalesce((select jsonb_agg(jsonb_build_object(
      'id', c.id, 'title', c.title,
      'lessons', coalesce((select jsonb_agg(jsonb_build_object(
          'id', l.id, 'title', l.title, 'done', exists (select 1 from lesson_progress lp where lp.student_id = p_student and lp.lesson_id = l.id),
          'items', coalesce((select jsonb_agg(jsonb_build_object('id', i.id, 'kind', i.kind, 'title', i.title, 'done', ip.item_id is not null, 'covered', vp.covered, 'duration', vp.duration,
                                'seconds', iv.seconds, 'opens', iv.opens, 'last_at', iv.last_at, 'ranges', vp.ranges) order by i.position, i.created_at)
                         from lesson_items i left join item_progress ip on ip.item_id = i.id and ip.student_id = p_student
                         left join video_progress vp on vp.item_id = i.id and vp.student_id = p_student
                         left join item_views iv on iv.item_id = i.id and iv.student_id = p_student where i.lesson_id = l.id), '[]'::jsonb),
          'quizzes', coalesce((select jsonb_agg(public._report_quiz(z.id, p_student) order by coalesce(z.lesson_pos, 100000), z.created_at) from quizzes z where z.lesson_id = l.id and z.is_published), '[]'::jsonb)
        ) order by l.position, l.created_at) from lessons l where l.course_id = c.id), '[]'::jsonb)
    ) order by c.sort_order, c.title) from enrollments e join courses c on c.id = e.course_id where e.student_id = p_student), '[]'::jsonb));
end $function$;

-- تقرير الطالب (الموجود) + التغطية الفعلية لكل فيديو
create or replace function public.student_report(p_student uuid, p_course uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare p jsonb; c jsonb; yr text; lessons jsonb; cq jsonb;
begin
  if not public.has_perm('reports.student') then raise exception 'forbidden'; end if;
  select to_jsonb(x) into p from profiles x where x.id = p_student; if p is null then raise exception 'not_found'; end if;
  yr := p ->> 'academic_year';
  select jsonb_build_object('id', id, 'title', title, 'description', description, 'academic_year', academic_year) into c from courses where id = p_course;
  if c is null then raise exception 'not_found'; end if;
  select coalesce(jsonb_agg(jsonb_build_object(
      'id', l.id, 'title', l.title, 'section', l.section_title, 'pos', l.position,
      'done', exists (select 1 from lesson_progress lp where lp.student_id = p_student and lp.lesson_id = l.id),
      'items', coalesce((select jsonb_agg(jsonb_build_object('id', i.id, 'kind', i.kind, 'title', i.title, 'pos', i.position,
                   'done', ip.item_id is not null, 'done_at', ip.done_at, 'opens', iv.opens, 'seconds', iv.seconds, 'last_at', iv.last_at,
                   'covered', vp.covered, 'duration', vp.duration) order by i.position, i.created_at)
                  from lesson_items i
                  left join item_progress ip on ip.item_id = i.id and ip.student_id = p_student
                  left join item_views iv on iv.item_id = i.id and iv.student_id = p_student
                  left join video_progress vp on vp.item_id = i.id and vp.student_id = p_student
                 where i.lesson_id = l.id), '[]'::jsonb),
      'quizzes', coalesce((select jsonb_agg(public._report_quiz(z.id, p_student) order by coalesce(z.lesson_pos, 100000), z.created_at)
                  from quizzes z where z.lesson_id = l.id and z.is_published), '[]'::jsonb)
    ) order by l.position, l.created_at), '[]'::jsonb) into lessons
    from lessons l where l.course_id = p_course;
  select coalesce(jsonb_agg(public._report_quiz(z.id, p_student) order by z.created_at), '[]'::jsonb) into cq
    from quizzes z where z.is_published and z.lesson_id is null
     and ((z.kind <> 'comprehensive' and z.course_id = p_course) or (z.kind = 'comprehensive' and yr is not null and z.academic_year = yr));
  perform public._audit('report.student', btrim(coalesce(p ->> 'first_name', '') || ' ' || coalesce(p ->> 'last_name', '')), jsonb_build_object('course', c ->> 'title'));
  return jsonb_build_object(
    'student', jsonb_build_object('id', p ->> 'id', 'first_name', p ->> 'first_name', 'middle_name', p ->> 'middle_name', 'last_name', p ->> 'last_name',
        'phone', p ->> 'phone_number', 'parent_phone', p ->> 'parent_phone', 'year', p ->> 'academic_year', 'governorate', p ->> 'governorate', 'created_at', p ->> 'created_at'),
    'course', c, 'lessons', lessons, 'course_quizzes', cq, 'generated_at', now(), 'need_pct', public._video_pct());
end $function$;

-- ---------------------------------------------------------------- 4) أكتر من حساب Bunny / R2
-- Bunny: مفتاح لكل مكتبة (secret_bunny_key_<رقم المكتبة>)، والمفتاح العام secret_bunny_key يفضل احتياطي.
-- R2: حساب إضافي باسم قصير (حروف إنجليزي صغيرة وأرقام): r2:اسم:مسار/ملف.mp4  أو  r2w:اسم:معرف/ملف
create or replace function public._r2_get(p_alias text, p_name text)
 RETURNS text
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select value from site_settings where key = case when p_alias is null or p_alias = '' then 'secret_r2_' || p_name else 'secret_r2a_' || p_alias || '_' || p_name end;
$function$;

create or replace function public._video_url(p_url text)
 RETURNS text
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
declare m text[]; k text; ex bigint; tok text; acc text; kid text; sec text; bkt text; base text; tkey text; amz text; host text; path text; al text;
begin
  if p_url is null then return p_url; end if;
  if p_url like 'bunny:%' then
    m := regexp_match(p_url, '^bunny:([0-9]+)/([0-9a-fA-F-]{36})$');
    if m is null then return null; end if;
    select value into k from site_settings where key = 'secret_bunny_key_' || m[1];
    if k is null then select value into k from site_settings where key = 'secret_bunny_key'; end if;
    if k is null then return null; end if;
    ex := extract(epoch from now())::bigint + 6 * 3600;
    tok := encode(digest(k || lower(m[2]) || ex::text, 'sha256'), 'hex');
    return 'https://iframe.mediadelivery.net/embed/' || m[1] || '/' || lower(m[2]) || '?token=' || tok || '&expires=' || ex || '&autoplay=false&preload=true&responsive=true';
  elsif p_url like 'r2:%' then
    m := regexp_match(p_url, '^r2:(?:([a-z0-9]{1,12}):)?([A-Za-z0-9._/-]{1,255})$');
    if m is null or m[2] like '%..%' or m[2] like '/%' then return null; end if;
    al := m[1];
    acc := public._r2_get(al, 'account'); kid := public._r2_get(al, 'key_id'); sec := public._r2_get(al, 'secret'); bkt := public._r2_get(al, 'bucket');
    if acc is null or kid is null or sec is null or bkt is null then return null; end if;
    amz := to_char(now() at time zone 'utc', 'YYYYMMDD"T"HH24MISS"Z"');
    host := acc || '.r2.cloudflarestorage.com'; path := '/' || bkt || '/' || m[2];
    return 'https://' || host || path || '?' || public._sigv4_get(host, path, kid, sec, 'auto', 's3', amz, 6 * 3600);
  elsif p_url like 'r2w:%' then
    m := regexp_match(p_url, '^r2w:(?:([a-z0-9]{1,12}):)?([A-Za-z0-9_-]{1,80})/([A-Za-z0-9._/-]{1,200})$');
    if m is null or m[3] like '%..%' then return null; end if;
    al := m[1];
    base := public._r2_get(al, 'worker_base'); tkey := public._r2_get(al, 'token_key');
    if base is null or tkey is null or base !~ '^https://[A-Za-z0-9.-]+(:[0-9]+)?(/[A-Za-z0-9._-]*)*$' then return null; end if;
    ex := extract(epoch from now())::bigint + 6 * 3600;
    tok := encode(hmac(convert_to(ex::text || ':' || m[2], 'utf8'), convert_to(tkey, 'utf8'), 'sha256'), 'hex');
    return rtrim(base, '/') || '/v/' || ex || '/' || tok || '/' || m[2] || '/' || m[3];
  end if;
  return p_url;
end $function$;

create or replace function public.set_secret(p_key text, p_value text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare base text;
begin
  if not public.staff_can_manage() then raise exception 'forbidden'; end if;
  if not (p_key in ('bunny_key', 'r2_account', 'r2_key_id', 'r2_secret', 'r2_bucket', 'r2_token_key', 'r2_worker_base')
          or p_key ~ '^bunny_key_[0-9]{1,10}$'
          or p_key ~ '^r2a_[a-z0-9]{1,12}_(account|key_id|secret|bucket|token_key|worker_base)$') then raise exception 'bad_key'; end if;
  base := regexp_replace(regexp_replace(p_key, '^r2a_[a-z0-9]{1,12}_', ''), '^r2_', '');
  if p_value is not null and btrim(p_value) <> '' then
    if base = 'account' and btrim(p_value) !~ '^[0-9a-fA-F]{32}$' then raise exception 'bad_value'; end if;
    if base = 'bucket' and btrim(p_value) !~ '^[a-z0-9][a-z0-9-]{1,61}[a-z0-9]$' then raise exception 'bad_value'; end if;
    if base = 'worker_base' and btrim(p_value) !~ '^https://[A-Za-z0-9.-]+(:[0-9]+)?(/[A-Za-z0-9._-]*)*$' then raise exception 'bad_value'; end if;
    if p_key ~ '^bunny_key' and length(btrim(p_value)) < 8 then raise exception 'bad_value'; end if;
  end if;
  if p_value is null or btrim(p_value) = '' then delete from site_settings where key = 'secret_' || p_key;
  else insert into site_settings (key, value, updated_by) values ('secret_' || p_key, btrim(p_value), auth.uid())
       on conflict (key) do update set value = excluded.value, updated_at = now(), updated_by = auth.uid(); end if;
  perform public._audit('settings.secret_' || p_key, null, null);
end $function$;

notify pgrst, 'reload schema';
select 'تم ✅ db_32 (حالات الحساب + تغطية الفيديو + الصفوف + Bunny/R2 المتعدد)' as status;
