-- =====================================================================
--  db_29_live_overview.sql  (النشاط المباشر + أرقام النظرة العامة)
--  شغّله في New query لوحده.
-- =====================================================================
alter table public.active_sessions add column if not exists seen_at timestamptz;
create index if not exists active_sessions_seen_idx on public.active_sessions (seen_at);

create or replace FUNCTION public.session_ok()
 RETURNS boolean
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare sid text := auth.jwt() ->> 'session_id'; cur text; sc timestamptz; newest boolean;
begin
  if auth.uid() is null then return false; end if;
  update active_sessions set seen_at = now() where user_id = auth.uid() and (seen_at is null or seen_at < now() - interval '50 seconds');   -- نبضة (للنشاط المباشر)
  if public.is_admin() or sid is null then return true; end if;          -- المالك مستثنى
  select session_id into cur from active_sessions where user_id = auth.uid();
  if cur = sid then return true; end if;
  begin
    select created_at into sc from auth.sessions where id::text = sid;
    if sc is null then return cur is null; end if;
    select not exists (select 1 from auth.sessions where user_id = auth.uid() and created_at > sc) into newest;
  exception when others then return cur is null; end;
  if newest then perform public._claim_session(auth.uid(), sid, sc); return true; end if;
  return false;
end $function$;

create or replace function public.live_activity()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare o jsonb; x jsonb; n int;
begin
  if not (public.has_perm('students.view') or public.has_perm('results.view')) then raise exception 'forbidden'; end if;
  select count(*) into n from active_sessions where seen_at > now() - interval '3 minutes';
  select coalesce(jsonb_agg(jsonb_build_object('id', p.id, 'name', btrim(concat_ws(' ', p.first_name, p.last_name)), 'year', p.academic_year, 'phone', p.phone_number, 'seen_at', s.seen_at) order by s.seen_at desc), '[]'::jsonb)
    into o from (select * from active_sessions where seen_at > now() - interval '3 minutes' order by seen_at desc limit 100) s join profiles p on p.id = s.user_id;
  select coalesce(jsonb_agg(jsonb_build_object('student_id', p.id, 'name', btrim(concat_ws(' ', p.first_name, p.last_name)), 'year', p.academic_year, 'phone', p.phone_number,
           'quiz_id', z.id, 'quiz', z.title, 'started_at', d.started_at, 'ends_at', d.ends_at, 'violations', d.violations,
           'answered', (select count(*) from jsonb_object_keys(d.answers)), 'total', (select count(*) from quiz_questions q where q.quiz_id = z.id), 'seen_at', d.updated_at) order by d.updated_at desc), '[]'::jsonb)
    into x from (select * from quiz_live_drafts where not done and updated_at > now() - interval '5 minutes' order by updated_at desc limit 100) d
      join profiles p on p.id = d.student_id join quizzes z on z.id = d.quiz_id;
  return jsonb_build_object('now', now(), 'online_count', n, 'online', o, 'in_exam', x,
    'today', jsonb_build_object('attempts', (select count(*) from quiz_attempts where created_at > date_trunc('day', now())),
                                'signups', (select count(*) from profiles where created_at > date_trunc('day', now()))));
end $function$;

create or replace function public.overview_stats()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if not public.is_admin() then raise exception 'forbidden'; end if;
  return jsonb_build_object(
    'students', (select count(*) from profiles),
    'new_7d', (select count(*) from profiles where created_at > now() - interval '7 days'),
    'active_24h', (select count(*) from active_sessions where seen_at > now() - interval '24 hours'),
    'online_now', (select count(*) from active_sessions where seen_at > now() - interval '3 minutes'),
    'attempts_7d', (select count(*) from quiz_attempts where created_at > now() - interval '7 days'),
    'avg_pct_7d', (select round(avg(case when total > 0 then score * 100.0 / total end)::numeric, 1) from quiz_attempts where created_at > now() - interval '7 days' and status <> 'pending'),
    'open_support', (select count(*) from support_threads where status = 'open'),
    'open_academic', (select count(*) from support_threads where status = 'open' and kind = 'academic' and not solved),
    'pending_essay', (select count(*) from quiz_attempts where status = 'pending'),
    'quizzes_open', (select count(*) from quizzes where is_published and (closes_at is null or closes_at > now())),
    'by_year', coalesce((select jsonb_object_agg(academic_year, c) from (select academic_year, count(*) c from profiles group by 1) q), '{}'::jsonb));
end $function$;
