-- =====================================================================
--  db_31_r2_video.sql  (تجهيز Cloudflare R2: روابط موقّعة بتنتهي + Worker محمي)
--  شغّله في New query لوحده. مش بيأثر على Bunny ولا على أي فيديو شغّال.
--  شكل الرابط في «محتوى الدرس»:
--     r2:مسار/الملف.mp4            ← رابط موقّع مباشر من R2 (من غير Worker)
--     r2w:معرّف-الفيديو/الملف       ← عن طريق Worker بتوقيع (للـHLS والحماية الأقوى)
-- =====================================================================

-- توقيع AWS SigV4 (الحجم الصغير: GET بس). R2 بيدعمه بنفس الطريقة.
create or replace function public._sigv4_get(p_host text, p_path text, p_key_id text, p_secret text, p_region text, p_service text, p_amzdate text, p_expires integer)
 RETURNS text
 LANGUAGE plpgsql
 IMMUTABLE
 SET search_path TO 'public', 'extensions'
AS $function$
declare d text := substr(p_amzdate, 1, 8); scope text := d || '/' || p_region || '/' || p_service || '/aws4_request'; q text; creq text; sts text; k bytea;
begin
  q := 'X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=' || replace(p_key_id || '/' || scope, '/', '%2F') || '&X-Amz-Date=' || p_amzdate || '&X-Amz-Expires=' || p_expires || '&X-Amz-SignedHeaders=host';
  creq := 'GET' || E'\n' || p_path || E'\n' || q || E'\n' || 'host:' || p_host || E'\n' || E'\n' || 'host' || E'\n' || 'UNSIGNED-PAYLOAD';
  sts := 'AWS4-HMAC-SHA256' || E'\n' || p_amzdate || E'\n' || scope || E'\n' || encode(digest(convert_to(creq, 'utf8'), 'sha256'), 'hex');
  k := hmac(convert_to(d, 'utf8'), convert_to('AWS4' || p_secret, 'utf8'), 'sha256');
  k := hmac(convert_to(p_region, 'utf8'), k, 'sha256');
  k := hmac(convert_to(p_service, 'utf8'), k, 'sha256');
  k := hmac(convert_to('aws4_request', 'utf8'), k, 'sha256');
  return q || '&X-Amz-Signature=' || encode(hmac(convert_to(sts, 'utf8'), k, 'sha256'), 'hex');
end $function$;

create or replace function public._video_url(p_url text)
 RETURNS text
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
declare m text[]; k text; ex bigint; tok text; acc text; kid text; sec text; bkt text; base text; tkey text; amz text; host text; path text;
begin
  if p_url is null then return p_url; end if;
  if p_url like 'bunny:%' then
    m := regexp_match(p_url, '^bunny:([0-9]+)/([0-9a-fA-F-]{36})$');
    if m is null then return null; end if;
    select value into k from site_settings where key = 'secret_bunny_key';
    if k is null then return null; end if;
    ex := extract(epoch from now())::bigint + 6 * 3600;
    tok := encode(digest(k || lower(m[2]) || ex::text, 'sha256'), 'hex');
    return 'https://iframe.mediadelivery.net/embed/' || m[1] || '/' || lower(m[2]) || '?token=' || tok || '&expires=' || ex || '&autoplay=false&preload=true&responsive=true';
  elsif p_url like 'r2:%' then
    m := regexp_match(p_url, '^r2:([A-Za-z0-9._/-]{1,255})$');
    if m is null or m[1] like '%..%' or m[1] like '/%' then return null; end if;
    select value into acc from site_settings where key = 'secret_r2_account';
    select value into kid from site_settings where key = 'secret_r2_key_id';
    select value into sec from site_settings where key = 'secret_r2_secret';
    select value into bkt from site_settings where key = 'secret_r2_bucket';
    if acc is null or kid is null or sec is null or bkt is null then return null; end if;
    amz := to_char(now() at time zone 'utc', 'YYYYMMDD"T"HH24MISS"Z"');
    host := acc || '.r2.cloudflarestorage.com'; path := '/' || bkt || '/' || m[1];
    return 'https://' || host || path || '?' || public._sigv4_get(host, path, kid, sec, 'auto', 's3', amz, 6 * 3600);
  elsif p_url like 'r2w:%' then
    m := regexp_match(p_url, '^r2w:([A-Za-z0-9_-]{1,80})/([A-Za-z0-9._/-]{1,200})$');
    if m is null or m[2] like '%..%' then return null; end if;
    select value into base from site_settings where key = 'secret_r2_worker_base';
    select value into tkey from site_settings where key = 'secret_r2_token_key';
    if base is null or tkey is null or base !~ '^https://[A-Za-z0-9.-]+(:[0-9]+)?(/[A-Za-z0-9._-]*)*$' then return null; end if;
    ex := extract(epoch from now())::bigint + 6 * 3600;
    tok := encode(hmac(convert_to(ex::text || ':' || m[1], 'utf8'), convert_to(tkey, 'utf8'), 'sha256'), 'hex');
    return rtrim(base, '/') || '/v/' || ex || '/' || tok || '/' || m[1] || '/' || m[2];
  end if;
  return p_url;
end $function$;

-- مفاتيح R2 (للمالك فقط — مابترجعش للمتصفح أبداً)
create or replace function public.set_secret(p_key text, p_value text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if not public.staff_can_manage() then raise exception 'forbidden'; end if;
  if p_key not in ('bunny_key', 'r2_account', 'r2_key_id', 'r2_secret', 'r2_bucket', 'r2_token_key', 'r2_worker_base') then raise exception 'bad_key'; end if;
  if p_value is not null and btrim(p_value) <> '' then
    if p_key = 'r2_account' and btrim(p_value) !~ '^[0-9a-fA-F]{32}$' then raise exception 'bad_value'; end if;
    if p_key = 'r2_bucket' and btrim(p_value) !~ '^[a-z0-9][a-z0-9-]{1,61}[a-z0-9]$' then raise exception 'bad_value'; end if;
    if p_key = 'r2_worker_base' and btrim(p_value) !~ '^https://[A-Za-z0-9.-]+(:[0-9]+)?(/[A-Za-z0-9._-]*)*$' then raise exception 'bad_value'; end if;
  end if;
  if p_value is null or btrim(p_value) = '' then delete from site_settings where key = 'secret_' || p_key;
  else insert into site_settings (key, value, updated_by) values ('secret_' || p_key, btrim(p_value), auth.uid())
       on conflict (key) do update set value = excluded.value, updated_at = now(), updated_by = auth.uid(); end if;
  perform public._audit('settings.secret_' || p_key, null, null);
end $function$;

create or replace function public.secret_status()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if not public.staff_can_manage() then raise exception 'forbidden'; end if;
  return (select coalesce(jsonb_object_agg(replace(key, 'secret_', ''), true), '{}'::jsonb) from site_settings where key like 'secret\_%')
         || jsonb_build_object('bunny_key', exists (select 1 from site_settings where key = 'secret_bunny_key'));
end $function$;
