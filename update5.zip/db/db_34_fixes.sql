-- =====================================================================
--  db_34_fixes.sql  (إصلاح «مستواي» + تعديلات تحديث 5) — شغّله في New query لوحده قبل db_35
-- =====================================================================

create or replace function public.my_level()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare uid uuid := auth.uid(); courses jsonb; exams jsonb; weak jsonb; tot jsonb; streak int := 0; best_run int := 0; run int := 0; prev date; d date; today date := (now() at time zone 'Africa/Cairo')::date; mistakes int;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  select coalesce(jsonb_agg(jsonb_build_object('id', c.id, 'title', c.title,
           'lessons', (select count(*) from lessons l where l.course_id = c.id),
           'lessons_done', (select count(*) from lesson_progress lp join lessons l on l.id = lp.lesson_id where lp.student_id = uid and l.course_id = c.id),
           'items', (select count(*) from lesson_items i join lessons l on l.id = i.lesson_id where l.course_id = c.id),
           'items_done', (select count(*) from item_progress ip join lesson_items i on i.id = ip.item_id join lessons l on l.id = i.lesson_id where ip.student_id = uid and l.course_id = c.id)) order by c.sort_order), '[]'::jsonb)
    into courses from enrollments e join courses c on c.id = e.course_id where e.student_id = uid;
  with a as (
    select z.id as quiz_id, z.title, z.lesson_id, z.course_id, z.kind, max(case when t.total > 0 then t.score * 100.0 / t.total end) as best, count(*) as tries, max(t.created_at) as last_at
      from quiz_attempts t join quizzes z on z.id = t.quiz_id where t.student_id = uid and t.status <> 'pending' group by z.id, z.title, z.lesson_id, z.course_id, z.kind)
  select coalesce(jsonb_agg(jsonb_build_object('quiz_id', quiz_id, 'title', title, 'best', round(best::numeric, 1), 'tries', tries, 'last_at', last_at) order by last_at desc), '[]'::jsonb) into exams from (select * from a order by last_at desc limit 30) q;
  with a as (
    select z.lesson_id, max(case when t.total > 0 then t.score * 100.0 / t.total end) as best, z.id
      from quiz_attempts t join quizzes z on z.id = t.quiz_id where t.student_id = uid and t.status <> 'pending' and z.lesson_id is not null group by z.id, z.lesson_id),
  b as (select lesson_id, avg(best) as pct, count(*) as n from a group by lesson_id)
  select coalesce(jsonb_agg(jsonb_build_object('lesson_id', b.lesson_id, 'lesson', l.title, 'course', c.title, 'pct', round(b.pct::numeric, 1), 'quizzes', b.n) order by b.pct), '[]'::jsonb) into weak
    from (select * from b order by pct limit 6) b join lessons l on l.id = b.lesson_id join courses c on c.id = l.course_id;
  select count(distinct x.question_id) into mistakes from quiz_attempt_answers x join quiz_attempts t on t.id = x.attempt_id where t.student_id = uid and x.is_correct = false;
  select jsonb_build_object(
      'attempts', (select count(*) from quiz_attempts where student_id = uid and status <> 'pending'),
      'avg_pct', (select round(avg(case when total > 0 then score * 100.0 / total end)::numeric, 1) from quiz_attempts where student_id = uid and status <> 'pending'),
      'perfect', (select count(*) from quiz_attempts where student_id = uid and status <> 'pending' and total > 0 and score >= total),
      'watch_minutes', (select round(coalesce(sum(seconds), 0) / 60.0) from item_views where student_id = uid),
      'lessons_done', (select count(*) from lesson_progress where student_id = uid),
      'items_done', (select count(*) from item_progress where student_id = uid),
      'mistakes', mistakes) into tot;
  for d in select distinct x from (
      select (created_at at time zone 'Africa/Cairo')::date as x from quiz_attempts where student_id = uid
      union select (completed_at at time zone 'Africa/Cairo')::date from lesson_progress where student_id = uid
      union select (done_at at time zone 'Africa/Cairo')::date from item_progress where student_id = uid
      union select (last_at at time zone 'Africa/Cairo')::date from item_views where student_id = uid) u order by x loop
    if prev is not null and d = prev + 1 then run := run + 1; else run := 1; end if;
    if run > best_run then best_run := run; end if;
    prev := d;
    streak := case when d >= today - 1 then run else 0 end;
  end loop;
  return jsonb_build_object('courses', courses, 'exams', exams, 'weak', weak, 'totals', tot, 'streak', streak, 'best_streak', best_run);
end $function$;

-- ---------------------------------------------------------------- المحاولات والقفل بنظام الصفوف
-- الأهداف المتاحة لكورس (الكورس + دروسه + امتحاناته) أو للامتحانات الشاملة لصف
create or replace function public.access_targets(p_course uuid DEFAULT NULL, p_year text DEFAULT NULL)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if not public.has_perm('students.view') then raise exception 'forbidden'; end if;
  if p_course is not null then
    return jsonb_build_object('course', (select jsonb_build_object('id', c.id, 'title', c.title, 'year', c.academic_year,
              'all', exists (select 1 from access_locks k where k.kind = 'course' and k.ref_id = c.id and k.student_id is null)) from courses c where c.id = p_course),
      'lessons', coalesce((select jsonb_agg(jsonb_build_object('id', l.id, 'title', l.title, 'section', l.section_title,
              'all', exists (select 1 from access_locks k where k.kind = 'lesson' and k.ref_id = l.id and k.student_id is null)) order by l.position, l.created_at) from lessons l where l.course_id = p_course), '[]'::jsonb),
      'quizzes', coalesce((select jsonb_agg(jsonb_build_object('id', z.id, 'title', z.title, 'kind', z.kind, 'hw', z.is_homework, 'max', z.max_attempts, 'published', z.is_published, 'lesson_id', z.lesson_id,
              'all', exists (select 1 from access_locks k where k.kind = 'quiz' and k.ref_id = z.id and k.student_id is null)) order by z.kind, z.created_at)
              from quizzes z where z.kind <> 'comprehensive' and (z.course_id = p_course or z.lesson_id in (select id from lessons where course_id = p_course))), '[]'::jsonb));
  end if;
  return jsonb_build_object('course', null, 'lessons', '[]'::jsonb,
      'quizzes', coalesce((select jsonb_agg(jsonb_build_object('id', z.id, 'title', z.title, 'kind', z.kind, 'hw', false, 'max', z.max_attempts, 'published', z.is_published, 'lesson_id', null,
              'all', exists (select 1 from access_locks k where k.kind = 'quiz' and k.ref_id = z.id and k.student_id is null)) order by z.created_at)
              from quizzes z where z.kind = 'comprehensive' and z.academic_year = p_year), '[]'::jsonb));
end $function$;

-- كل طلاب الصف + حالة كل طالب في الهدف المختار (كورس / درس / امتحان)
create or replace function public.access_grid(p_year text, p_kind text, p_ref uuid, p_course uuid DEFAULT NULL)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare mx int;
begin
  if not public.has_perm('students.view') then raise exception 'forbidden'; end if;
  if p_kind not in ('course', 'lesson', 'quiz') then raise exception 'bad_kind'; end if;
  if p_kind = 'quiz' then select max_attempts into mx from quizzes where id = p_ref; end if;
  return coalesce((select jsonb_agg(x.j order by x.nm) from (
    select public._pname(p) as nm, jsonb_build_object(
      'id', p.id, 'name', public._pname(p), 'phone', p.phone_number, 'status', p.account_status,
      'enrolled', case when p_course is null then true else exists (select 1 from enrollments e where e.student_id = p.id and e.course_id = p_course) end,
      'me', exists (select 1 from access_locks k where k.kind = p_kind and k.ref_id = p_ref and k.student_id = p.id),
      'used', case when p_kind = 'quiz' then (select count(*) from quiz_attempts a where a.quiz_id = p_ref and a.student_id = p.id) end,
      'max', mx,
      'archived', case when p_kind = 'quiz' then (select count(*) from quiz_attempt_archive r where r.quiz_id = p_ref and r.student_id = p.id) end,
      'best', case when p_kind = 'quiz' then (select max(case when a.total > 0 then round(a.score * 100.0 / a.total, 1) end) from quiz_attempts a where a.quiz_id = p_ref and a.student_id = p.id) end,
      'pending', case when p_kind = 'quiz' then exists (select 1 from quiz_attempts a where a.quiz_id = p_ref and a.student_id = p.id and a.status = 'pending') end,
      'last_at', case when p_kind = 'quiz' then (select max(a.created_at) from quiz_attempts a where a.quiz_id = p_ref and a.student_id = p.id) end,
      'done', case when p_kind = 'lesson' then exists (select 1 from lesson_progress lp where lp.student_id = p.id and lp.lesson_id = p_ref) end,
      'lessons', case when p_kind = 'course' then (select count(*) from lessons l where l.course_id = p_ref) end,
      'lessons_done', case when p_kind = 'course' then (select count(*) from lesson_progress lp join lessons l on l.id = lp.lesson_id where lp.student_id = p.id and l.course_id = p_ref) end
    ) as j from profiles p where p.academic_year = p_year) x), '[]'::jsonb);
end $function$;

-- إجراءات جماعية (لمجموعة طلاب مختارين)
create or replace function public.grant_new_attempt_bulk(p_quiz uuid, p_students uuid[])
 RETURNS integer
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare s uuid; n int := 0;
begin
  if not public.has_perm('students.attempts') then raise exception 'forbidden'; end if;
  if p_students is null or array_length(p_students, 1) is null then return 0; end if;
  if array_length(p_students, 1) > 500 then raise exception 'too_many'; end if;
  foreach s in array p_students loop
    if exists (select 1 from profiles where id = s) then perform public.grant_new_attempt(p_quiz, s); n := n + 1; end if;
  end loop;
  return n;
end $function$;

create or replace function public.set_lock_bulk(p_kind text, p_ref uuid, p_students uuid[], p_locked boolean)
 RETURNS integer
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare s uuid; n int := 0;
begin
  if not public.has_perm('students.locks') then raise exception 'forbidden'; end if;
  if p_kind not in ('course', 'lesson', 'quiz') then raise exception 'bad_kind'; end if;
  if p_students is null or array_length(p_students, 1) is null then return 0; end if;
  if array_length(p_students, 1) > 500 then raise exception 'too_many'; end if;
  foreach s in array p_students loop
    if p_locked then
      insert into access_locks (kind, ref_id, student_id) select p_kind, p_ref, s
       where not exists (select 1 from access_locks where kind = p_kind and ref_id = p_ref and student_id = s);
    else delete from access_locks where kind = p_kind and ref_id = p_ref and student_id = s; end if;
    n := n + 1;
  end loop;
  perform public._audit(case when p_locked then 'lock.bulk_on' else 'lock.bulk_off' end, p_kind || ':' || p_ref::text, jsonb_build_object('count', n));
  return n;
end $function$;

create or replace function public.reset_course_progress_bulk(p_course uuid, p_students uuid[])
 RETURNS integer
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare s uuid; n int := 0;
begin
  if not public.has_perm('students.attempts') then raise exception 'forbidden'; end if;
  if p_students is null or array_length(p_students, 1) is null then return 0; end if;
  if array_length(p_students, 1) > 500 then raise exception 'too_many'; end if;
  foreach s in array p_students loop perform public.reset_course_progress(p_course, s); n := n + 1; end loop;
  return n;
end $function$;

notify pgrst, 'reload schema';
select 'تم ✅ db_34' as status;
