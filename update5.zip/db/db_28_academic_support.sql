-- =====================================================================
--  db_28_academic_support.sql  (الدعم العلمي + ردود جاهزة + تم الحل)
--  شغّله في New query لوحده.
-- =====================================================================
alter table public.support_threads add column if not exists kind text not null default 'tech';
alter table public.support_threads drop constraint if exists support_threads_kind_check;
alter table public.support_threads add constraint support_threads_kind_check check (kind in ('tech', 'academic'));
alter table public.support_threads add column if not exists context jsonb;
alter table public.support_threads add column if not exists solved boolean not null default false;
alter table public.support_threads add column if not exists solved_at timestamptz;
create index if not exists support_thr_kind_idx on public.support_threads (kind, status, last_at desc);

-- الدوال القديمة اتغيّر شكل مدخلاتها: نشيل القديم عشان ما يحصلش تعارض
drop function if exists public.support_begin(text, boolean, text);
drop function if exists public.support_admin_list(text);

-- ردود جاهزة (بتتدار من لوحة التحكم)
create table if not exists public.support_canned (
  id uuid primary key default gen_random_uuid(),
  kind text not null default 'all' check (kind in ('all', 'tech', 'academic')),
  title text not null check (char_length(btrim(title)) between 1 and 60),
  body text not null check (char_length(btrim(body)) between 1 and 1500),
  position integer not null default 0,
  created_at timestamptz not null default now()
);
alter table public.support_canned enable row level security;
drop policy if exists sc_sel on public.support_canned; drop policy if exists sc_ins on public.support_canned; drop policy if exists sc_upd on public.support_canned; drop policy if exists sc_del on public.support_canned;
create policy sc_sel on public.support_canned for select to authenticated using ((select public.has_perm('support.view')));
create policy sc_ins on public.support_canned for insert to authenticated with check ((select public.has_perm('support.reply')));
create policy sc_upd on public.support_canned for update to authenticated using ((select public.has_perm('support.reply'))) with check ((select public.has_perm('support.reply')));
create policy sc_del on public.support_canned for delete to authenticated using ((select public.has_perm('support.reply')));
revoke all on public.support_canned from anon;
grant select, insert, update, delete on public.support_canned to authenticated;

-- علامة «تم الحل»
create or replace function public.support_admin_solved(p_thread uuid, p_solved boolean DEFAULT true)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if not public.has_perm('support.reply') then raise exception 'forbidden'; end if;
  update support_threads set solved = coalesce(p_solved, true), solved_at = case when coalesce(p_solved, true) then now() else null end where id = p_thread;
  if not found then raise exception 'not_found'; end if;
end $function$;

-- عدّاد المحادثات غير المقروءة لكل نوع (للنقط الحمرا في القايمة)
create or replace function public.support_admin_counts()
 RETURNS jsonb
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select case when not public.has_perm('support.view') then null else jsonb_build_object(
    'tech', (select count(*) from support_threads where kind = 'tech' and status = 'open' and unread_admin > 0),
    'academic', (select count(*) from support_threads where kind = 'academic' and status = 'open' and unread_admin > 0),
    'open_tech', (select count(*) from support_threads where kind = 'tech' and status = 'open'),
    'open_academic', (select count(*) from support_threads where kind = 'academic' and status = 'open'),
    'unsolved_academic', (select count(*) from support_threads where kind = 'academic' and status = 'open' and not solved)) end;
$function$;

create or replace function public.support_begin(p_name text, p_phone_ok boolean DEFAULT true, p_phone text DEFAULT NULL::text, p_kind text DEFAULT 'tech', p_context jsonb DEFAULT NULL)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare k text := case when p_kind = 'academic' then 'academic' else 'tech' end; ctx jsonb; welcome text; pid uuid; pp text; li boolean := false; nm text; ph text; alt text; t support_threads%rowtype; cnt int; body text; words int; prof_name text;
begin
  nm := btrim(regexp_replace(coalesce(p_name, ''), '\s+', ' ', 'g'));
  ctx := case when p_context is not null and jsonb_typeof(p_context) = 'object' then jsonb_strip_nulls(jsonb_build_object(
           'course', left(btrim(coalesce(p_context ->> 'course', '')), 120), 'lesson', left(btrim(coalesce(p_context ->> 'lesson', '')), 160),
           'topic', left(btrim(coalesce(p_context ->> 'topic', '')), 200), 'course_id', case when (p_context ->> 'course_id') ~ '^[0-9a-f-]{36}$' then p_context ->> 'course_id' end)) else null end;
  if ctx is not null and ctx = '{}'::jsonb then ctx := null; end if;
  if k = 'academic' and auth.uid() is null then raise exception 'login_required'; end if;
  words := cardinality(string_to_array(nm, ' '));
  if char_length(nm) < 5 or char_length(nm) > 80 or words < 3 or nm ~ '[0-9<>@#$%^&*()_+=/\\|{}\[\]~`"]' or exists (select 1 from unnest(string_to_array(nm, ' ')) w where char_length(w) < 2) then
    raise exception 'bad_name';
  end if;
  if auth.uid() is not null then
    select id, phone_number, btrim(concat_ws(' ', first_name, middle_name, last_name)) into pid, pp, prof_name from profiles where id = auth.uid();
    li := pid is not null;
  end if;
  if not li then
    ph := regexp_replace(coalesce(p_phone, ''), '\D', '', 'g');
    if length(ph) < 8 then raise exception 'bad_phone'; end if;
    select id, phone_number, btrim(concat_ws(' ', first_name, middle_name, last_name)) into pid, pp, prof_name from profiles
      where regexp_replace(coalesce(phone_number, ''), '\D', '', 'g') = ph limit 1;
    if pid is null then raise exception 'not_registered'; end if;
    select count(*) into cnt from support_threads where student_id = pid and not verified and created_at > now() - interval '1 day';
    if cnt >= 3 then raise exception 'too_many'; end if;
  else
    select * into t from support_threads where student_id = pid and verified and status = 'open' and kind = k order by last_at desc limit 1;
    if found then
      return jsonb_build_object('thread_id', t.id, 'token', t.token, 'existing', true, 'kind', k);
    end if;
    select count(*) into cnt from support_threads where student_id = pid and verified and created_at > now() - interval '1 day';
    if cnt >= 10 then raise exception 'too_many'; end if;
  end if;
  if not coalesce(p_phone_ok, true) then
    alt := regexp_replace(coalesce(p_phone, ''), '\D', '', 'g');
    if alt !~ '^01[0-9]{9}$' then raise exception 'bad_phone'; end if;
  end if;
  insert into support_threads (student_id, phone, name, typed_name, phone_ok, alt_phone, verified, kind, context)
    values (pid, regexp_replace(coalesce(pp, '00000000'), '\D', '', 'g'), prof_name, nm, coalesce(p_phone_ok, true), alt, li, k, ctx)
    returning * into t;
  body := '👤 الاسم: ' || nm || E'\n' || '📱 الرقم المسجّل على المنصة: ' || coalesce(pp, '—')
       || case when coalesce(p_phone_ok, true) then E'\n✅ الطالب أكّد إن الرقم صحيح' else E'\n⚠️ الطالب قال إن الرقم غير صحيح — الرقم الصحيح عنده: ' || alt end
       || case when k = 'academic' then E'\n📘 دعم علمي' || coalesce(E'\n📚 الكورس: ' || nullif(ctx ->> 'course', ''), '') || coalesce(E'\n🎬 الدرس: ' || nullif(ctx ->> 'lesson', ''), '') || coalesce(E'\n❓ الموضوع: ' || nullif(ctx ->> 'topic', ''), '') else '' end;
  insert into support_messages (thread_id, sender, body, is_auto, created_at) values (t.id, 'student', body, true, clock_timestamp());
  welcome := case when k = 'academic'
    then 'أهلاً بك يا ' || split_part(nm, ' ', 1) || ' في الدعم العلمي 📘' || E'\n' || 'اكتب سؤالك بوضوح (وتقدر تصوّر السؤال أو حلّك وتبعته) وهيرد عليك المدرس أو فريق المادة في أقرب وقت.'
    else 'أهلاً بك يا ' || split_part(nm, ' ', 1) || ' في منصة The Leader In English 👋' || E'\n' || 'اكتب مشكلتك أو استفسارك بالتفصيل (وتقدر تبعت صورة) وهنرد عليك في أقرب وقت.' end;
  insert into support_messages (thread_id, sender, body, is_auto, created_at) values (t.id, 'staff', welcome, true, clock_timestamp() + interval '20 milliseconds');
  update support_threads set last_at = now() where id = t.id;
  return jsonb_build_object('thread_id', t.id, 'token', t.token, 'existing', false, 'kind', k);
end $function$;

create or replace FUNCTION public.support_my_threads()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  return coalesce((select jsonb_agg(x.j order by x.last_at desc) from (
    select t.last_at, jsonb_build_object('id', t.id, 'token', t.token, 'status', t.status, 'created_at', t.created_at, 'last_at', t.last_at,
             'unread', t.unread_student, 'kind', t.kind, 'solved', t.solved, 'context', t.context,
             'last', (select left(coalesce(m.body, '📷 صورة'), 90) from support_messages m where m.thread_id = t.id and not m.is_auto order by m.created_at desc limit 1)) as j
      from support_threads t where t.student_id = auth.uid() and t.verified order by t.last_at desc limit 50) x), '[]'::jsonb);
end $function$;

create or replace function public.support_admin_list(p_status text DEFAULT 'open', p_kind text DEFAULT NULL)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if not public.has_perm('support.view') then raise exception 'forbidden'; end if;
  return coalesce((select jsonb_agg(q.x order by q.last_at desc) from (
    select jsonb_build_object('id', t.id, 'name', coalesce(t.typed_name, t.name), 'profile_name', t.name, 'phone', t.phone, 'alt_phone', t.alt_phone, 'phone_ok', t.phone_ok,
           'status', t.status, 'kind', t.kind, 'solved', t.solved, 'context', t.context, 'unread', t.unread_admin, 'last_at', t.last_at, 'verified', t.verified,
           'last', (select coalesce(m.body, '📷 صورة') from support_messages m where m.thread_id = t.id and not m.is_auto order by m.created_at desc limit 1)) as x, t.last_at
      from support_threads t where (p_status = 'all' or t.status = p_status) and (p_kind is null or p_kind = 'all' or t.kind = p_kind) order by t.last_at desc limit 200) q), '[]'::jsonb);
end $function$;

create or replace FUNCTION public.support_admin_thread(p_thread uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare t support_threads%rowtype; p profiles%rowtype;
begin
  if not public.has_perm('support.view') then raise exception 'forbidden'; end if;
  select * into t from support_threads where id = p_thread; if not found then raise exception 'not_found'; end if;
  update support_threads set unread_admin = 0, admin_seen_at = now() where id = t.id;
  if t.student_id is not null then select * into p from profiles where id = t.student_id; end if;
  return jsonb_build_object('id', t.id, 'name', coalesce(t.typed_name, t.name), 'profile_name', t.name, 'phone', t.phone, 'alt_phone', t.alt_phone, 'phone_ok', t.phone_ok,
    'status', t.status, 'kind', t.kind, 'solved', t.solved, 'context', t.context, 'student_id', t.student_id, 'verified', t.verified, 'student_seen_at', t.student_seen_at,
    'student', case when p.id is null then null else jsonb_build_object('academic_year', p.academic_year, 'parent_phone', p.parent_phone, 'email', p.email) end,
    'messages', coalesce((select jsonb_agg(jsonb_build_object('id', m.id, 'sender', m.sender, 'body', m.body, 'image_url', m.image_url, 'is_auto', m.is_auto, 'created_at', m.created_at) order by m.created_at)
                            from support_messages m where m.thread_id = t.id), '[]'::jsonb));
end $function$;
