-- =====================================================================
--  db_30_student_features.sql  (مستواي + استكمال الفيديو + ملاحظات الفيديو)
--  شغّله في New query لوحده.
-- =====================================================================

-- مكان وقف الفيديو (صف واحد صغير لكل طالب لكل فيديو)
create table if not exists public.video_progress (
  student_id uuid not null references auth.users(id) on delete cascade,
  item_id uuid not null references public.lesson_items(id) on delete cascade,
  seconds integer not null default 0 check (seconds >= 0 and seconds <= 86400),
  duration integer check (duration is null or (duration >= 0 and duration <= 86400)),
  updated_at timestamptz not null default now(),
  primary key (student_id, item_id)
);
alter table public.video_progress enable row level security;
drop policy if exists vp_own on public.video_progress;
create policy vp_own on public.video_progress for select to authenticated using (student_id = (select auth.uid()));
revoke all on public.video_progress from anon, authenticated;
grant select on public.video_progress to authenticated;

-- ملاحظات الطالب على وقت معيّن في الفيديو
create table if not exists public.lesson_notes (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references auth.users(id) on delete cascade,
  item_id uuid not null references public.lesson_items(id) on delete cascade,
  at_sec integer not null default 0 check (at_sec >= 0 and at_sec <= 86400),
  body text not null check (char_length(btrim(body)) between 1 and 500),
  created_at timestamptz not null default now()
);
create index if not exists lesson_notes_own_idx on public.lesson_notes (student_id, item_id, at_sec);
alter table public.lesson_notes enable row level security;
drop policy if exists ln_own on public.lesson_notes;
create policy ln_own on public.lesson_notes for select to authenticated using (student_id = (select auth.uid()));
revoke all on public.lesson_notes from anon, authenticated;
grant select on public.lesson_notes to authenticated;

create or replace function public.video_pos_save(p_item uuid, p_sec integer, p_dur integer DEFAULT NULL)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  if p_item is null or p_sec is null then return; end if;
  if not exists (select 1 from lesson_items where id = p_item) then return; end if;
  insert into video_progress (student_id, item_id, seconds, duration, updated_at)
    values (auth.uid(), p_item, least(greatest(p_sec, 0), 86400), case when p_dur between 1 and 86400 then p_dur end, now())
  on conflict (student_id, item_id) do update
    set seconds = excluded.seconds, duration = coalesce(excluded.duration, video_progress.duration), updated_at = now();
end $function$;

create or replace function public.video_pos_get(p_item uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare r video_progress%rowtype;
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  select * into r from video_progress where student_id = auth.uid() and item_id = p_item;
  if not found then return null; end if;
  return jsonb_build_object('seconds', r.seconds, 'duration', r.duration, 'updated_at', r.updated_at);
end $function$;

create or replace function public.note_add(p_item uuid, p_sec integer, p_body text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare n lesson_notes%rowtype; cnt int;
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  p_body := btrim(coalesce(p_body, ''));
  if p_body = '' then raise exception 'empty'; end if;
  if length(p_body) > 500 then raise exception 'too_long'; end if;
  if not exists (select 1 from lesson_items where id = p_item) then raise exception 'not_found'; end if;
  select count(*) into cnt from lesson_notes where student_id = auth.uid() and item_id = p_item;
  if cnt >= 100 then raise exception 'too_many'; end if;
  insert into lesson_notes (student_id, item_id, at_sec, body) values (auth.uid(), p_item, least(greatest(coalesce(p_sec, 0), 0), 86400), p_body) returning * into n;
  return jsonb_build_object('id', n.id, 'at_sec', n.at_sec, 'body', n.body, 'created_at', n.created_at);
end $function$;

create or replace function public.note_list(p_item uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  return coalesce((select jsonb_agg(jsonb_build_object('id', n.id, 'at_sec', n.at_sec, 'body', n.body, 'created_at', n.created_at) order by n.at_sec, n.created_at)
                     from lesson_notes n where n.student_id = auth.uid() and n.item_id = p_item), '[]'::jsonb);
end $function$;

create or replace function public.note_del(p_id uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  delete from lesson_notes where id = p_id and student_id = auth.uid();
end $function$;

-- «مستواي»: بيتحسب لحظة الطلب من بيانات موجودة (مفيش تخزين إضافي)
create or replace function public.my_level()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare uid uuid := auth.uid(); courses jsonb; exams jsonb; weak jsonb; tot jsonb; streak int := 0; best_run int := 0; run int := 0; prev date; d date; today date := (now() at time zone 'Africa/Cairo')::date; mistakes int;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  select coalesce(jsonb_agg(jsonb_build_object('id', c.id, 'title', c.title,
           'lessons', (select count(*) from lessons l where l.course_id = c.id),
           'lessons_done', (select count(*) from lesson_progress lp join lessons l on l.id = lp.lesson_id where lp.student_id = uid and l.course_id = c.id),
           'items', (select count(*) from lesson_items i join lessons l on l.id = i.lesson_id where l.course_id = c.id),
           'items_done', (select count(*) from item_progress ip join lesson_items i on i.id = ip.item_id join lessons l on l.id = i.lesson_id where ip.student_id = uid and l.course_id = c.id)) order by c.sort_order), '[]'::jsonb)
    into courses from enrollments e join courses c on c.id = e.course_id where e.student_id = uid;
  with a as (
    select z.id as quiz_id, z.title, z.lesson_id, z.course_id, z.kind, max(case when t.total > 0 then t.score * 100.0 / t.total end) as best, count(*) as tries, max(t.created_at) as last_at
      from quiz_attempts t join quizzes z on z.id = t.quiz_id where t.student_id = uid and t.status <> 'pending' group by z.id, z.title, z.lesson_id, z.course_id, z.kind)
  select coalesce(jsonb_agg(jsonb_build_object('quiz_id', quiz_id, 'title', title, 'best', round(best::numeric, 1), 'tries', tries, 'last_at', last_at) order by last_at desc), '[]'::jsonb) into exams from (select * from a order by last_at desc limit 30) q;
  with a as (
    select z.lesson_id, max(case when t.total > 0 then t.score * 100.0 / t.total end) as best, z.id
      from quiz_attempts t join quizzes z on z.id = t.quiz_id where t.student_id = uid and t.status <> 'pending' and z.lesson_id is not null group by z.id, z.lesson_id),
  b as (select lesson_id, avg(best) as pct, count(*) as n from a group by lesson_id)
  select coalesce(jsonb_agg(jsonb_build_object('lesson_id', b.lesson_id, 'lesson', l.title, 'course', c.title, 'pct', round(b.pct::numeric, 1), 'quizzes', b.n) order by b.pct), '[]'::jsonb) into weak
    from (select * from b order by pct limit 6) b join lessons l on l.id = b.lesson_id join courses c on c.id = l.course_id;
  select count(distinct x.question_id) into mistakes from quiz_attempt_answers x join quiz_attempts t on t.id = x.attempt_id where t.student_id = uid and x.is_correct = false;
  select jsonb_build_object(
      'attempts', (select count(*) from quiz_attempts where student_id = uid and status <> 'pending'),
      'avg_pct', (select round(avg(case when total > 0 then score * 100.0 / total end)::numeric, 1) from quiz_attempts where student_id = uid and status <> 'pending'),
      'perfect', (select count(*) from quiz_attempts where student_id = uid and status <> 'pending' and total > 0 and score >= total),
      'watch_minutes', (select round(coalesce(sum(seconds), 0) / 60.0) from item_views where student_id = uid),
      'lessons_done', (select count(*) from lesson_progress where student_id = uid),
      'items_done', (select count(*) from item_progress where student_id = uid),
      'mistakes', mistakes) into tot;
  for d in select distinct x from (
      select (created_at at time zone 'Africa/Cairo')::date as x from quiz_attempts where student_id = uid
      union select (completed_at at time zone 'Africa/Cairo')::date from lesson_progress where student_id = uid
      union select (done_at at time zone 'Africa/Cairo')::date from item_progress where student_id = uid
      union select (last_at at time zone 'Africa/Cairo')::date from item_views where student_id = uid) u order by x loop
    if prev is not null and d = prev + 1 then run := run + 1; else run := 1; end if;
    if run > best_run then best_run := run; end if;
    prev := d;
    streak := case when d >= today - 1 then run else 0 end;
  end loop;
  return jsonb_build_object('courses', courses, 'exams', exams, 'weak', weak, 'totals', tot, 'streak', streak, 'best_streak', best_run);
end $function$;
