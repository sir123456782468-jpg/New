-- =====================================================================
--  فحص صحة وأمان القاعدة (للقراءة فقط — شغّله في أي وقت بعد ما تخلّص الأجزاء)
--  كل صف لازم يطلع ✅ . لو في ❌ ابعتلي الصف.
-- =====================================================================
create or replace function public._health()
returns table (الفحص text, النتيجة text, سليم text) language plpgsql set search_path = public as $$
declare t text; n int; r text; fake uuid := gen_random_uuid(); bad text;
  prot text[] := array['admins','staff','banned_identities','access_locks','quiz_starts','quiz_live_drafts','code_attempts','active_sessions','item_views','notif_reads','support_threads','support_messages','banner_dismissals','site_settings','activation_codes','admin_audit','login_events','quiz_questions','quiz_answers','lesson_items','lesson_content','quiz_attempt_archive','site_banners','quiz_extensions'];
begin
  select count(*) into n from pg_tables where schemaname = 'public';
  return query select 'عدد الجداول (39)', n::text, case when n = 39 then '✅' else '❌' end;
  select count(*) into n from pg_tables where schemaname = 'public' and not rowsecurity;
  return query select 'جداول من غير حماية RLS (0)', n::text, case when n = 0 then '✅' else '❌' end;
  select count(*) into n from pg_proc p join pg_namespace s on s.oid = p.pronamespace where s.nspname = 'public' and p.prokind = 'f';
  return query select 'عدد الدوال', n::text, case when n >= 80 then '✅' else '❌' end;
  select string_agg(distinct p.proname, ', ' order by p.proname) into r from pg_proc p join pg_namespace s on s.oid = p.pronamespace
   where s.nspname = 'public' and p.prokind = 'f' and has_function_privilege('anon', p.oid, 'execute');
  return query select 'دوال مفتوحة لغير المسجّل (المفروض 5 بس)', r, case when r = 'student_exists, support_begin, support_fetch, support_send, support_start' then '✅' else '❌' end;
  select string_agg(c.relname, ', ') into r from pg_class c join pg_namespace s on s.oid = c.relnamespace
   where s.nspname = 'public' and c.relkind = 'r' and (has_table_privilege('anon', c.oid, 'select') or has_table_privilege('anon', c.oid, 'insert'));
  return query select 'جداول متاحة لغير المسجّل (0)', coalesce(r, '0'), case when r is null then '✅' else '❌' end;
  select count(*) into n from pg_trigger where tgname = 'on_auth_user_owner' and not tgisinternal;
  return query select 'ربط المالك بالإيميل (تريجر)', n::text, case when n = 1 then '✅' else '❌ شغّل: select public.link_owner_now();' end;
  select count(*) into n from admins a join auth.users u on u.id = a.user_id where a.is_owner and lower(u.email) = public._owner_email();
  return query select 'حساب المالك اتربط (' || public._owner_email() || ')', n::text, case when n = 1 then '✅' else '⚠️ لسه ما عملتش الحساب أو ما أكدتوش' end;
  select count(*) into n from pg_policies where schemaname = 'storage' and policyname in ('cm_read','cm_ins','cm_upd','cm_del','lf_read','lf_ins','lf_upd','lf_del','sp_ins','sp_read','ef_ins','ef_read');
  return query select 'سياسات رفع الملفات (12)', n::text, case when n = 12 then '✅' else '❌ رفع الصور ممكن ما يشتغلش' end;
  select count(*) into n from storage.buckets where id in ('course-media', 'lesson-files', 'support-files', 'essay-files');
  return query select 'buckets الملفات (4)', n::text, case when n = 4 then '✅' else '❌' end;

  -- محاكاة طالب عادي: مفروض مايشوفش ولا يعمل أي حاجة حساسة
  perform set_config('request.jwt.claim.sub', fake::text, true);
  perform set_config('request.jwt.claims', json_build_object('sub', fake, 'role', 'authenticated')::text, true);
  set local role authenticated;
  bad := '';
  foreach t in array prot loop
    begin execute format('select count(*) from public.%I', t) into n; if n <> 0 then bad := bad || t || ' '; end if;
    exception when insufficient_privilege then null; when others then bad := bad || t || '(!) '; end;
  end loop;
  reset role;
  return query select 'طالب عادي مايشوفش جداول محمية', coalesce(nullif(bad, ''), 'مفيش'), case when bad = '' then '✅' else '❌' end;
  perform set_config('request.jwt.claim.sub', fake::text, true);
  set local role authenticated;
  begin perform public.generate_codes(gen_random_uuid(), 1, null, null, null); r := '❌ اتنفّذت'; exception when others then r := '✅'; end;
  begin perform public.set_blocked(fake, true); r := '❌ ' || r; exception when others then null; end;
  begin insert into public.quiz_attempts (quiz_id, student_id, score, total) values (gen_random_uuid(), fake, 10, 10); r := '❌ ' || r; exception when others then null; end;
  begin perform public.grade_attempt(fake, gen_random_uuid(), '{}', 0, 0); r := '❌ ' || r; exception when others then null; end;
  select case when public.is_admin() then 1 else 0 end into n;
  reset role;
  return query select 'طالب عادي مايولّدش أكواد/مايحظرش/مايكتبش نتيجة', r, case when r = '✅' then '✅' else '❌' end;
  return query select 'طالب عادي مش أدمن', (n = 0)::text, case when n = 0 then '✅' else '❌' end;
end $$;
revoke all on function public._health() from public, anon, authenticated;

select * from public._health();

drop function public._health();
