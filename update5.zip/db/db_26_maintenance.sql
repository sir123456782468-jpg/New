-- =====================================================================
--  db_26_maintenance.sql  (الاستهلاك والصيانة: قياس المساحة + تنظيف آمن للمالك فقط)
--  شغّله في New query لوحده.
-- =====================================================================

-- صلاحية حذف ملفات الصور القديمة (للأدمن فقط)
do $$
begin
  drop policy if exists ef_del on storage.objects;
  create policy ef_del on storage.objects for delete to authenticated using (bucket_id = 'essay-files' and (select public.is_admin()));
  drop policy if exists sp_del on storage.objects;
  create policy sp_del on storage.objects for delete to authenticated using (bucket_id = 'support-files' and (select public.is_admin()));
exception when others then raise notice 'storage policies skipped: %', sqlerrm;
end $$;

-- 1) أرقام الاستهلاك
create or replace function public.usage_stats()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare tb jsonb; stg jsonb := '[]'::jsonb; au bigint := 0; att bigint; ans bigint; per_attempt numeric := 0;
begin
  if not public.is_admin() then raise exception 'forbidden'; end if;
  select coalesce(jsonb_agg(x order by (x->>'bytes')::bigint desc), '[]'::jsonb) into tb from (
    select jsonb_build_object('name', c.relname, 'bytes', pg_total_relation_size(c.oid), 'rows', greatest(c.reltuples, coalesce(s.n_live_tup, 0), 0)::bigint) as x
      from pg_class c left join pg_stat_user_tables s on s.relid = c.oid
     where c.relnamespace = 'public'::regnamespace and c.relkind = 'r'
     order by pg_total_relation_size(c.oid) desc limit 14) t;
  begin
    select coalesce(jsonb_agg(jsonb_build_object('bucket', bucket_id, 'files', n, 'bytes', b) order by b desc), '[]'::jsonb) into stg
      from (select bucket_id, count(*) as n, coalesce(sum((metadata ->> 'size')::bigint), 0) as b from storage.objects group by bucket_id) q;
  exception when others then stg := '[]'::jsonb; end;
  begin select count(*) into au from auth.users; exception when others then au := 0; end;
  select count(*) into att from quiz_attempts; select count(*) into ans from quiz_attempt_answers;
  if att > 0 then per_attempt := (pg_total_relation_size('public.quiz_attempts') + pg_total_relation_size('public.quiz_attempt_answers'))::numeric / att; end if;
  return jsonb_build_object(
    'at', now(), 'db_bytes', pg_database_size(current_database()), 'tables', tb, 'storage', stg, 'auth_users', au, 'per_attempt', round(per_attempt),
    'counts', jsonb_build_object('students', (select count(*) from profiles), 'courses', (select count(*) from courses), 'lessons', (select count(*) from lessons),
        'quizzes', (select count(*) from quizzes), 'questions', (select count(*) from quiz_questions), 'attempts', att, 'answers', ans,
        'support_threads', (select count(*) from support_threads), 'support_messages', (select count(*) from support_messages),
        'login_events', (select count(*) from login_events), 'audit', (select count(*) from admin_audit), 'archive', (select count(*) from quiz_attempt_archive),
        'notifications', (select count(*) from notifications), 'drafts', (select count(*) from quiz_live_drafts)));
end $function$;

-- مساعد: حجم ملف في storage
create or replace function public._obj_size(p_bucket text, p_name text)
 RETURNS bigint
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare n bigint := 0;
begin
  begin select coalesce((o.metadata ->> 'size')::bigint, 0) into n from storage.objects o where o.bucket_id = p_bucket and o.name = p_name limit 1; exception when others then n := 0; end;
  return coalesce(n, 0);
end $function$;

create or replace function public._support_path(p_url text) returns text
 LANGUAGE sql IMMUTABLE
AS $$ select nullif(regexp_replace(coalesce(p_url, ''), '^.*/support-files/', ''), '') $$;

-- 2) معاينة: كام عنصر هيتحذف وبكام حجم (من غير ما يحذف حاجة)
create or replace function public.cleanup_preview(p_kind text, p_days integer)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare n bigint := 0; b bigint := 0; lim timestamptz := now() - make_interval(days => greatest(coalesce(p_days, 0), 0));
begin
  if not public.is_owner() then raise exception 'forbidden'; end if;
  if p_kind = 'essay_images' then
    select count(*), coalesce(sum(public._obj_size('essay-files', x.essay_image)), 0) into n, b
      from quiz_attempt_answers x join quiz_attempts a on a.id = x.attempt_id
     where x.essay_image is not null and x.essay_score is not null and a.created_at < lim;
  elsif p_kind = 'support_images' then
    select count(*), coalesce(sum(public._obj_size('support-files', public._support_path(m.image_url))), 0) into n, b
      from support_messages m where m.image_url is not null and m.created_at < lim;
  elsif p_kind = 'support_closed' then
    select count(*) into n from support_threads where status = 'closed' and last_at < lim;
  elsif p_kind = 'login_events' then select count(*) into n from login_events where created_at < lim;
  elsif p_kind = 'audit' then select count(*) into n from admin_audit where at < lim;
  elsif p_kind = 'archive' then select count(*) into n from quiz_attempt_archive where archived_at < lim;
  elsif p_kind = 'drafts' then select count(*) into n from quiz_live_drafts where updated_at < lim and done;
  elsif p_kind = 'notifications' then select count(*) into n from notifications where created_at < lim;
  else raise exception 'bad_kind'; end if;
  return jsonb_build_object('kind', p_kind, 'days', p_days, 'count', n, 'bytes', b);
end $function$;

-- 3) صور: نجيب مسارات دفعة (والمتصفح يمسحها من التخزين ثم ينادي cleanup_mark)
create or replace function public.cleanup_list(p_kind text, p_days integer, p_limit integer DEFAULT 100)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare lim timestamptz := now() - make_interval(days => greatest(coalesce(p_days, 0), 0)); r jsonb;
begin
  if not public.is_owner() then raise exception 'forbidden'; end if;
  if p_kind = 'essay_images' then
    select coalesce(jsonb_agg(distinct x.essay_image), '[]'::jsonb) into r from (
      select x.essay_image from quiz_attempt_answers x join quiz_attempts a on a.id = x.attempt_id
       where x.essay_image is not null and x.essay_score is not null and a.created_at < lim limit least(greatest(p_limit, 1), 500)) x;
  elsif p_kind = 'support_images' then
    select coalesce(jsonb_agg(distinct p), '[]'::jsonb) into r from (
      select public._support_path(m.image_url) as p from support_messages m where m.image_url is not null and m.created_at < lim limit least(greatest(p_limit, 1), 500)) s where p is not null;
  else raise exception 'bad_kind'; end if;
  return r;
end $function$;

create or replace function public.cleanup_mark(p_kind text, p_paths text[])
 RETURNS integer
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare n int := 0;
begin
  if not public.is_owner() then raise exception 'forbidden'; end if;
  if p_kind = 'essay_images' then
    update quiz_attempt_answers set essay_image = null where essay_image = any (p_paths); get diagnostics n = row_count;
  elsif p_kind = 'support_images' then
    update support_messages set image_url = null, body = coalesce(nullif(btrim(body), ''), '🖼️ (اتحذفت الصورة لتوفير المساحة)')
     where public._support_path(image_url) = any (p_paths); get diagnostics n = row_count;
  else raise exception 'bad_kind'; end if;
  perform public._audit('maintenance.images', p_kind, jsonb_build_object('rows', n));
  return n;
end $function$;

-- 4) حذف سجلات (من غير ملفات)
create or replace function public.cleanup_run(p_kind text, p_days integer)
 RETURNS integer
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare n int := 0; lim timestamptz := now() - make_interval(days => greatest(coalesce(p_days, 0), 0));
begin
  if not public.is_owner() then raise exception 'forbidden'; end if;
  if p_days is null or p_days < 1 then raise exception 'bad_days'; end if;
  if p_kind = 'login_events' then delete from login_events where created_at < lim; get diagnostics n = row_count;
  elsif p_kind = 'audit' then delete from admin_audit where at < lim; get diagnostics n = row_count;
  elsif p_kind = 'archive' then delete from quiz_attempt_archive where archived_at < lim; get diagnostics n = row_count;
  elsif p_kind = 'drafts' then delete from quiz_live_drafts where updated_at < lim and done; get diagnostics n = row_count;
  elsif p_kind = 'notifications' then
    delete from notif_reads r where r.ref like 'n:%' and exists (select 1 from notifications x where 'n:' || x.id = r.ref and x.created_at < lim);
    delete from notifications where created_at < lim; get diagnostics n = row_count;
  elsif p_kind = 'support_closed' then delete from support_threads where status = 'closed' and last_at < lim; get diagnostics n = row_count;
  else raise exception 'bad_kind'; end if;
  perform public._audit('maintenance.cleanup', p_kind, jsonb_build_object('days', p_days, 'deleted', n));
  return n;
end $function$;
