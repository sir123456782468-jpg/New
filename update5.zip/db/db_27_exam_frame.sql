-- =====================================================================
--  db_27_exam_frame.sql  (تصميم الأسئلة: القطع + إطار الامتحان لكل صف)
--  شغّله في New query لوحده.
-- =====================================================================

-- ---------- القطع (Passage): بتتكتب مرة وتتربط بأي عدد أسئلة ----------
create table if not exists public.quiz_passages (
  id uuid primary key default gen_random_uuid(),
  quiz_id uuid not null references public.quizzes(id) on delete cascade,
  position integer not null default 0,
  title text check (title is null or length(title) <= 120),
  body text not null check (length(btrim(body)) > 0 and length(body) <= 20000),
  created_at timestamptz not null default now()
);
create index if not exists quiz_passages_quiz_idx on public.quiz_passages (quiz_id);
alter table public.quiz_passages enable row level security;
drop policy if exists qp_sel on public.quiz_passages;
drop policy if exists qp_ins on public.quiz_passages;
drop policy if exists qp_upd on public.quiz_passages;
drop policy if exists qp_del on public.quiz_passages;
create policy qp_sel on public.quiz_passages for select to authenticated
  using ((select public.has_perm('content.view')) or (select public.has_perm('content.edit')) or (select public.has_perm('content.delete')) or (select public.has_perm('results.view')));
create policy qp_ins on public.quiz_passages for insert to authenticated with check ((select public.has_perm('content.edit')));
create policy qp_upd on public.quiz_passages for update to authenticated using ((select public.has_perm('content.edit'))) with check ((select public.has_perm('content.edit')));
create policy qp_del on public.quiz_passages for delete to authenticated using ((select public.has_perm('content.delete')) or (select public.has_perm('content.edit')));
revoke all on public.quiz_passages from anon;
grant select, insert, update, delete on public.quiz_passages to authenticated;

alter table public.quiz_questions add column if not exists passage_id uuid references public.quiz_passages(id) on delete set null;
create index if not exists quiz_questions_passage_idx on public.quiz_questions (passage_id);

-- السؤال ما يتربطش بقطعة من امتحان تاني
create or replace function public._qp_check() returns trigger
 LANGUAGE plpgsql
AS $function$
begin
  if new.passage_id is not null and not exists (select 1 from quiz_passages p where p.id = new.passage_id and p.quiz_id = new.quiz_id) then
    raise exception 'bad_passage';
  end if;
  return new;
end $function$;
drop trigger if exists qp_check on public.quiz_questions;
create trigger qp_check before insert or update of passage_id, quiz_id on public.quiz_questions for each row execute function public._qp_check();

-- ---------- إطار الامتحان (الهيدر/الفوتر/الشعار/المدرس/السوشيال) لكل صف ----------
create or replace function public._frame_defaults() returns jsonb
 LANGUAGE sql IMMUTABLE
AS $$ select '{"show_header":true,"show_footer":true,"show_chips":true,"show_logo":true,"show_photo":true,"show_social":true,"show_grade":true,"show_site":true,
  "brand_title":"The Leader","brand_sub":"IN ENGLISH","header_pill":"","teacher_name":"","teacher_sub":"The Leader In English","site_url":"","facebook":"","whatsapp":"",
  "grade_label":"","grade_num":"","c1":"#6b2d5c","c2":"#7d3a6c","a1":"#ef4444","a2":"#ec4899"}'::jsonb $$;

-- بيسيب المفاتيح المعروفة بس ويتأكد من النوع/الطول (حماية من أي محتوى غريب)
create or replace function public._frame_clean(j jsonb) returns jsonb
 LANGUAGE plpgsql IMMUTABLE
AS $function$
declare k text; o jsonb := '{}'::jsonb; v text;
begin
  if j is null or jsonb_typeof(j) <> 'object' then return o; end if;
  foreach k in array array['show_header','show_footer','show_chips','show_logo','show_photo','show_social','show_grade','show_site'] loop
    if j ? k and jsonb_typeof(j -> k) = 'boolean' then o := o || jsonb_build_object(k, j -> k); end if;
  end loop;
  foreach k in array array['brand_title','brand_sub','header_pill','teacher_name','teacher_sub','site_url','facebook','whatsapp','grade_label','grade_num'] loop
    if j ? k and jsonb_typeof(j -> k) = 'string' then v := left(btrim(j ->> k), 80); o := o || jsonb_build_object(k, v); end if;
  end loop;
  foreach k in array array['c1','c2','a1','a2'] loop
    if j ? k and jsonb_typeof(j -> k) = 'string' and (j ->> k) ~ '^#[0-9a-fA-F]{6}$' then o := o || jsonb_build_object(k, lower(j ->> k)); end if;
  end loop;
  return o;
end $function$;

-- لوحة التحكم: قراءة/حفظ
create or replace function public.exam_frame_admin()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare raw jsonb; s jsonb;
begin
  if not (public.has_perm('content.view') or public.has_perm('content.edit')) then raise exception 'forbidden'; end if;
  select coalesce(nullif(value, '')::jsonb, '{}'::jsonb) into raw from site_settings where key = 'exam_frame';
  select coalesce(jsonb_object_agg(key, value), '{}'::jsonb) into s from site_settings where key in ('teacher_name', 'teacher_photo', 'platform_name');
  return jsonb_build_object('defaults', public._frame_defaults(), 'saved', coalesce(raw, '{}'::jsonb), 'settings', s);
end $function$;

create or replace function public.exam_frame_save(p_frame jsonb)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare out jsonb := jsonb_build_object('default', public._frame_clean(p_frame -> 'default'), 'years', '{}'::jsonb); y text;
begin
  if not public.has_perm('content.edit') then raise exception 'forbidden'; end if;
  if jsonb_typeof(p_frame) <> 'object' then raise exception 'bad_frame'; end if;
  for y in select jsonb_object_keys(coalesce(p_frame -> 'years', '{}'::jsonb)) loop
    if y in ('أولى إعدادي', 'ثانية إعدادي', 'ثالثة إعدادي', 'أولى ثانوي', 'ثانية ثانوي', 'ثالثة ثانوي') then
      out := jsonb_set(out, array['years', y], public._frame_clean(p_frame -> 'years' -> y));
    end if;
  end loop;
  insert into site_settings (key, value, updated_by) values ('exam_frame', out::text, auth.uid())
    on conflict (key) do update set value = excluded.value, updated_at = now(), updated_by = auth.uid();
  perform public._audit('settings.exam_frame', null, null);
end $function$;

-- للطالب: الإطار النهائي لصفه (p_v = نسخة مخزّنة عنده، لو لسه سارية بنرجّع unchanged ونوفّر الصورة)
create or replace function public.exam_frame(p_year text DEFAULT NULL, p_v text DEFAULT NULL)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare yr text; raw jsonb; f jsonb; ver text; tn text; ph text; pn text; gn text; gl text;
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  select coalesce(p_year, academic_year) into yr from profiles where id = auth.uid();
  yr := coalesce(yr, p_year);
  select coalesce(nullif(value, '')::jsonb, '{}'::jsonb) into raw from site_settings where key = 'exam_frame';
  ver := md5(coalesce(raw::text, '') || coalesce((select max(updated_at)::text from site_settings where key in ('exam_frame', 'teacher_photo', 'teacher_name', 'platform_name')), '') || coalesce(yr, ''));
  if p_v is not null and p_v = ver then return jsonb_build_object('v', ver, 'unchanged', true); end if;
  f := public._frame_defaults() || coalesce(raw -> 'default', '{}'::jsonb) || coalesce(raw -> 'years' -> yr, '{}'::jsonb);
  select value into tn from site_settings where key = 'teacher_name';
  select value into ph from site_settings where key = 'teacher_photo';
  select value into pn from site_settings where key = 'platform_name';
  if coalesce(f ->> 'teacher_name', '') = '' then f := f || jsonb_build_object('teacher_name', coalesce(nullif(tn, ''), 'Mr. Sherif Khafagy')); end if;
  gn := case yr when 'أولى إعدادي' then '1' when 'ثانية إعدادي' then '2' when 'ثالثة إعدادي' then '3' when 'أولى ثانوي' then '1' when 'ثانية ثانوي' then '2' when 'ثالثة ثانوي' then '3' else '' end;
  gl := case when yr like '%إعدادي' then 'الإعدادي' when yr like '%ثانوي' then 'الثانوي' else '' end;
  if coalesce(f ->> 'grade_num', '') = '' then f := f || jsonb_build_object('grade_num', gn); end if;
  if coalesce(f ->> 'grade_label', '') = '' then f := f || jsonb_build_object('grade_label', gl); end if;
  f := f || jsonb_build_object('year', yr, 'v', ver, 'platform_name', coalesce(nullif(pn, ''), 'The Leader In English'));
  if (f ->> 'show_photo')::boolean and ph is not null then f := f || jsonb_build_object('photo', ph); end if;
  return f;
end $function$;

-- ---------- start_quiz و quiz_review بيرجّعوا القطع ----------
create or replace function public.start_quiz(p_quiz uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare qz quizzes%rowtype; v_started timestamptz; v_n int; v_q jsonb; v_win interval; v_close timestamptz;
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  select * into qz from quizzes where id = p_quiz;
  if not found then raise exception 'not_found'; end if;
  if public.access_locked('quiz', p_quiz) then raise exception 'locked'; end if;
  if not public.can_access_quiz(p_quiz) then raise exception 'not_allowed'; end if;
  v_close := public._eff_close(p_quiz, auth.uid());
  if qz.opens_at is not null and now() < qz.opens_at then raise exception 'not_open'; end if;
  if v_close is not null and now() > v_close then raise exception 'closed'; end if;
  select count(*) into v_n from quiz_attempts where student_id = auth.uid() and quiz_id = p_quiz;
  if qz.max_attempts > 0 and v_n >= qz.max_attempts then raise exception 'max_attempts'; end if;

  v_win := case when qz.time_limit_minutes is null then interval '6 hours' else make_interval(mins => qz.time_limit_minutes) + interval '5 minutes' end;
  insert into quiz_starts (student_id, quiz_id) values (auth.uid(), p_quiz)
  on conflict (student_id, quiz_id) do update
    set started_at = case when quiz_starts.started_at < now() - v_win then now() else quiz_starts.started_at end
  returning started_at into v_started;

  select coalesce(jsonb_agg(jsonb_build_object('id', q.id, 'question', q.question, 'options', q.options,
                                               'qtype', q.qtype, 'points', q.points, 'image_url', q.image_url, 'passage_id', q.passage_id) order by q.position, q.created_at), '[]'::jsonb)
    into v_q from quiz_questions q where q.quiz_id = p_quiz;
  return jsonb_build_object('started_at', v_started, 'now', now(), 'closes_at', v_close, 'questions', v_q,
    'passages', coalesce((select jsonb_agg(jsonb_build_object('id', p.id, 'title', p.title, 'body', p.body) order by p.position, p.created_at) from quiz_passages p
                          where p.quiz_id = p_quiz and exists (select 1 from quiz_questions q2 where q2.passage_id = p.id)), '[]'::jsonb));
end $function$

;
create or replace function public.quiz_review(p_attempt uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  a quiz_attempts%rowtype; z quizzes%rowtype; used int; can boolean; hid text;
  nq int; nc int; nw int; nu int; ne int; qs jsonb;
begin
  select * into a from quiz_attempts where id = p_attempt and student_id = auth.uid();
  if not found then raise exception 'not_found'; end if;
  select * into z from quizzes where id = a.quiz_id;
  select count(*) into used from quiz_attempts where quiz_id = a.quiz_id and student_id = auth.uid();
  can := used >= coalesce(z.max_attempts, 1) or (z.closes_at is not null and z.closes_at < now());
  hid := quiz_result_hidden(z.result_mode, a.status, z.closes_at, used, z.max_attempts);

  if hid is not null then
    return jsonb_build_object('attempt_id', a.id, 'quiz_id', a.quiz_id, 'title', z.title, 'hidden', true, 'hidden_reason', hid,
      'result_mode', z.result_mode, 'pending', (a.status = 'pending'), 'max_attempts', coalesce(z.max_attempts, 1), 'attempts_used', used,
      'created_at', a.created_at, 'can_review', false, 'questions', '[]'::jsonb);
  end if;

  select count(*)::int,
         (count(*) filter (where q.qtype = 'mcq' and x.is_correct is true))::int,
         (count(*) filter (where q.qtype = 'mcq' and x.chosen_index is not null and x.is_correct is not true))::int,
         (count(*) filter (where x.chosen_index is null and (nullif(btrim(coalesce(x.essay_text, '')), '') is null and x.essay_image is null)))::int,
         (count(*) filter (where q.qtype <> 'mcq' and (nullif(btrim(coalesce(x.essay_text, '')), '') is not null or x.essay_image is not null) and x.essay_score is null))::int
    into nq, nc, nw, nu, ne
    from quiz_questions q left join quiz_attempt_answers x on x.question_id = q.id and x.attempt_id = a.id
   where q.quiz_id = a.quiz_id;

  if can then
    select coalesce(jsonb_agg(jsonb_build_object(
             'id', q.id, 'position', q.position, 'passage_id', q.passage_id, 'question', q.question, 'image_url', q.image_url,
             'qtype', q.qtype, 'points', q.points, 'options', q.options, 'note', q.note, 'feedback', x.feedback,
             'pick_n', coalesce(q.pick_n, 1), 'correct_set', qa.correct_set, 'chosen_multi', x.chosen_multi, 'multi_score', x.multi_score,
             'correct_index', qa.correct_index, 'chosen_index', x.chosen_index, 'is_correct', x.is_correct,
             'essay_text', x.essay_text, 'essay_image', x.essay_image, 'essay_score', x.essay_score) order by q.position), '[]'::jsonb)
      into qs
      from quiz_questions q
      left join quiz_attempt_answers x on x.question_id = q.id and x.attempt_id = a.id
      left join quiz_answers qa on qa.question_id = q.id
     where q.quiz_id = a.quiz_id;
  else qs := '[]'::jsonb; end if;

  return jsonb_build_object(
    'attempt_id', a.id, 'quiz_id', a.quiz_id, 'title', z.title, 'pass_percent', z.pass_percent, 'result_note', z.result_note,
    'score', a.score, 'total', a.total, 'pending', (a.status = 'pending'), 'hidden', false,
    'passed', case when a.status = 'pending' then null
                   when a.total > 0 then (a.score::numeric / a.total * 100 >= coalesce(z.pass_percent, 50)) else false end,
    'n_questions', nq, 'n_correct', nc, 'n_wrong', nw, 'n_unanswered', nu, 'n_essay_pending', ne,
    'max_attempts', coalesce(z.max_attempts, 1), 'attempts_used', used,
    'violations', a.violations, 'seconds_spent', a.seconds_spent, 'created_at', a.created_at,
    'can_review', can, 'questions', qs,
    'passages', case when can then coalesce((select jsonb_agg(jsonb_build_object('id', p.id, 'title', p.title, 'body', p.body) order by p.position, p.created_at) from quiz_passages p
                        where p.quiz_id = a.quiz_id and exists (select 1 from quiz_questions q2 where q2.passage_id = p.id)), '[]'::jsonb) else '[]'::jsonb end);
end $function$

;
